﻿# Удаление Power Quality Report на Windows
# Запуск: powershell -ExecutionPolicy Bypass -File uninstall-windows.ps1

$ErrorActionPreference = "SilentlyContinue"

function Ok   { param($msg) Write-Host "[OK]  $msg" -ForegroundColor Green }
function Warn { param($msg) Write-Host "[!!]  $msg" -ForegroundColor Yellow }
function Info { param($msg) Write-Host "[..]  $msg" }

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

Write-Host "=== Удаление Power Quality Report ===" -ForegroundColor Cyan
Write-Host ""

# ── 1. Остановка контейнеров и удаление образов ───────────────────────────────
Info "Остановка контейнеров и удаление образов..."
docker compose down --rmi all 2>$null | Out-Null
docker stop pq_report_nginx pq_report_app 2>$null | Out-Null
docker rm   pq_report_nginx pq_report_app 2>$null | Out-Null
docker rmi pq-report-app gauss-analytics-app microservice-app 2>$null | Out-Null
Ok "Контейнеры и образы удалены"

# ── 2. (резерв — уже сделано выше) ───────────────────────────────────────────

# ── 3. Задача автозапуска ─────────────────────────────────────────────────────
Info "Удаление задачи автозапуска..."
$task = Get-ScheduledTask -TaskName "PowerQualityReport-Autostart" -ErrorAction SilentlyContinue
if ($task) {
    Unregister-ScheduledTask -TaskName "PowerQualityReport-Autostart" -Confirm:$false
    Ok "Задача автозапуска удалена"
} else {
    Warn "Задача автозапуска не найдена — пропускаем"
}

# ── 4. Очистка БД GAUSS ───────────────────────────────────────────────────────
Info "Очистка записей в БД GAUSS..."
$psql = (Get-ChildItem "C:\Program Files\PostgreSQL" -Recurse -Filter "psql.exe" -ErrorAction SilentlyContinue | Select-Object -First 1).FullName
if ($psql) {
    $sql = @"
DELETE FROM admin.project_tree WHERE name = 'Power Quality Report';
DELETE FROM admin.page WHERE body LIKE '%:8000%';
"@
    $env:PGPASSWORD = "postgres"
    $sql | & $psql -U postgres -d ags -f - 2>&1 | Out-Null
    Ok "Записи микросервиса удалены из БД GAUSS"
} else {
    Warn "psql не найден — удалите записи из БД GAUSS вручную"
}

# ── 5. Удаление папки установки ───────────────────────────────────────────────
$installDir = "C:\power-quality-report"
if (Test-Path $installDir) {
    Info "Удаление папки $installDir..."
    Remove-Item $installDir -Recurse -Force
    Ok "Папка $installDir удалена"
} else {
    Warn "Папка $installDir не найдена — пропускаем"
}

Write-Host ""
Write-Host "=== Удаление завершено ===" -ForegroundColor Cyan
Write-Host "Power Quality Report полностью удалён с этого компьютера."
