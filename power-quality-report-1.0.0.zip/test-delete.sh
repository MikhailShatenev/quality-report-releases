#!/bin/bash
echo "============================================"
echo " Удаление тестовых устройств и данных"
echo "============================================"
echo ""
read -p "Удалить все тестовые данные? (y/N): " CONFIRM
if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
    echo "Отменено."
    exit 0
fi
echo ""
docker exec -it pq_report_app python /app/setup_test_env.py delete
if [ $? -eq 0 ]; then
    echo ""
    echo "[OK] Тестовые данные удалены."
else
    echo ""
    echo "[ERR] Ошибка. Убедитесь что микросервис запущен: docker compose ps"
fi
