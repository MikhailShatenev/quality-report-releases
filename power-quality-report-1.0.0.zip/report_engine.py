"""
Аналитическое ядро: расчёты по ГОСТ 32144-2013.

Получает данные из report DB по parameter_uuid (не по address строке).
"""

import os
import psycopg2
import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime

# ─── ГОСТ 32144-2013 нормы ───────────────────────────────────────────────────
GOST = {
    'voltage_nominal_3ph':   230.0,   # В фазное (для 380В трёхфазной)
    'voltage_nominal_1ph':   220.0,   # В (для однофазной 220В)
    'voltage_dev_normal':    5.0,     # %
    'voltage_dev_max':       10.0,    # %
    'asymmetry_normal':      2.0,     # % K2U
    'asymmetry_max':         4.0,     # %
    'freq_nominal':          50.0,    # Гц
    'freq_dev_normal':       0.2,     # Гц
    'freq_dev_max':          0.4,     # Гц
    'pf_min':                0.92,
    'pf_alarm':              0.85,
    'thd_voltage_normal':    8.0,     # % THD напряжения для 0.4кВ (нормально допустимое)
    'thd_voltage_max':      12.0,     # % THD напряжения для 0.4кВ (максимально допустимое)
}

# Connection to report DB (has VIEWs of trend data)
REPORT_DB = dict(
    host     = os.environ.get('PG_HOST', 'localhost'),
    port     = int(os.environ.get('PG_PORT', 5432)),
    dbname   = 'report',
    user     = os.environ.get('PG_USER', 'postgres'),
    password = os.environ.get('PG_PASS', 'postgres'),
)

# Direct connection to ags DB (bypasses slow dblink VIEW in report.trends)
AGS_DB = dict(
    host     = os.environ.get('PG_HOST', 'localhost'),
    port     = int(os.environ.get('PG_PORT', 5432)),
    dbname   = os.environ.get('PG_AGS_DB', 'ags'),
    user     = os.environ.get('PG_USER', 'postgres'),
    password = os.environ.get('PG_PASS', 'postgres'),
)


@dataclass
class MetricResult:
    name: str
    unit: str
    mean: float
    min: float
    max: float
    std: float
    gost_limit: Optional[float] = None
    violations_pct: Optional[float] = None
    status: str = 'ok'   # ok / warn / crit / no_data


@dataclass
class ChannelResult:
    """Result for one measurement channel (= one 3-phase circuit)."""
    channel: int
    voltage_nominal: int              # 220 or 380
    load_name: str                    = ''  # пользовательское название нагрузки
    voltage:     list[MetricResult]  = field(default_factory=list)
    current:     list[MetricResult]  = field(default_factory=list)
    power:       dict                = field(default_factory=dict)
    asymmetry:   dict                = field(default_factory=dict)
    frequency:   Optional[MetricResult] = None
    power_factor: Optional[MetricResult] = None
    energy:      dict                = field(default_factory=dict)
    extra:       dict                = field(default_factory=dict)  # device-specific extras
    missing_params: list[str]        = field(default_factory=list)
    has_data:    bool                = True


@dataclass
class DeviceReport:
    device_name: str
    device_type: str        # 'map3e', 'map12e', 'optimer', 'optimat'
    device_type_label: str  # 'OptiSmart MAP3E', 'OptiMer M500', etc.
    folder_id: int
    period_start: datetime
    period_end: datetime
    total_records: int
    interval_hours: float
    channels: list[ChannelResult] = field(default_factory=list)
    violations: list[str]         = field(default_factory=list)
    warnings:   list[str]         = field(default_factory=list)
    missing_trends: list[str]     = field(default_factory=list)
    outages:    list[dict]        = field(default_factory=list)
    recommendations: list         = field(default_factory=list)


# ─── Data loading ────────────────────────────────────────────────────────────

def load_series(param_uuid: str,
                date_from: datetime = None,
                date_to: datetime = None) -> pd.Series:
    """Loads time series for a single parameter. Uses ags direct query (fast)."""
    try:
        conn = psycopg2.connect(**AGS_DB)
        cur = conn.cursor()
        query = """
            SELECT tl.date_create, NULLIF(tl.value, '')::double precision
            FROM admin.trend_log tl
            JOIN admin.trend t ON t.uuid = tl.trend_uuid
            WHERE t.parameter_uuid = %s::uuid
        """
        params = [param_uuid]
        if date_from:
            query += " AND tl.date_create >= %s"
            params.append(date_from)
        if date_to:
            query += " AND tl.date_create <= %s"
            params.append(date_to)
        query += " ORDER BY tl.date_create"
        cur.execute(query, params)
        rows = cur.fetchall()
        cur.close()
        conn.close()
        if not rows:
            return pd.Series(dtype=float, name=param_uuid)
        times, values = zip(*rows)
        return pd.Series(list(values),
                         index=pd.DatetimeIndex(list(times)),
                         name=param_uuid)
    except Exception:
        return pd.Series(dtype=float, name=param_uuid)


def load_all_series(resolved: dict[str, str],
                    date_from: datetime = None,
                    date_to: datetime = None) -> dict[str, pd.Series]:
    """
    Loads all logical parameters in a SINGLE DB query.
    resolved: {logical_name: param_uuid}
    """
    if not resolved:
        return {}

    uuid_to_logical = {v: k for k, v in resolved.items()}
    uuids = list(resolved.values())

    rows = []
    try:
        conn = psycopg2.connect(**AGS_DB)
        cur = conn.cursor()
        query = """
            SELECT t.parameter_uuid::text, tl.date_create,
                   NULLIF(tl.value, '')::double precision AS value
            FROM admin.trend_log tl
            JOIN admin.trend t ON t.uuid = tl.trend_uuid
            WHERE t.parameter_uuid::text = ANY(%s)
        """
        params: list = [uuids]
        if date_from:
            query += " AND tl.date_create >= %s"
            params.append(date_from)
        if date_to:
            query += " AND tl.date_create <= %s"
            params.append(date_to)
        query += " ORDER BY t.parameter_uuid, tl.date_create"
        cur.execute(query, params)
        rows = cur.fetchall()
        cur.close()
        conn.close()
    except Exception:
        return {k: pd.Series(dtype=float, name=v) for k, v in resolved.items()}

    from collections import defaultdict
    buckets: dict[str, list] = defaultdict(list)
    for puuid, ts, val in rows:
        buckets[puuid].append((ts, val))

    result = {}
    for logical, puuid in resolved.items():
        pts = buckets.get(puuid, [])
        if pts:
            times, values = zip(*pts)
            result[logical] = pd.Series(list(values),
                                        index=pd.DatetimeIndex(list(times)),
                                        name=puuid)
        else:
            result[logical] = pd.Series(dtype=float, name=puuid)
    return result


# ─── Calculations ────────────────────────────────────────────────────────────

def _metric(name: str, unit: str, s: pd.Series,
            gost_limit: float = None,
            limit_type: str = 'max') -> MetricResult:
    s = s.dropna()
    if s.empty:
        return MetricResult(name=name, unit=unit, mean=0, min=0,
                            max=0, std=0, status='no_data')
    viol_pct = None
    if gost_limit is not None:
        if limit_type == 'max':
            viol_pct = float((s > gost_limit).mean() * 100)
        elif limit_type == 'min':
            viol_pct = float((s < gost_limit).mean() * 100)
        elif limit_type == 'abs':
            viol_pct = float((s.abs() > gost_limit).mean() * 100)
    status = 'ok'
    if viol_pct is not None:
        status = 'crit' if viol_pct > 5 else ('warn' if viol_pct > 0 else 'ok')
    return MetricResult(
        name=name, unit=unit,
        mean=round(float(s.mean()), 3),
        min=round(float(s.min()), 3),
        max=round(float(s.max()), 3),
        std=round(float(s.std()), 3),
        gost_limit=gost_limit,
        violations_pct=round(viol_pct, 1) if viol_pct is not None else None,
        status=status,
    )


def _voltage_dev_pct(u: pd.Series, u_nom: float) -> pd.Series:
    return (u - u_nom) / u_nom * 100


def _asymmetry_k2u(l1: pd.Series, l2: pd.Series, l3: pd.Series) -> pd.Series:
    df = pd.DataFrame({'l1': l1, 'l2': l2, 'l3': l3}).dropna()
    if df.empty:
        return pd.Series(dtype=float)
    u_avg = df.mean(axis=1)
    return df.sub(u_avg, axis=0).abs().max(axis=1) / u_avg * 100


def _current_asymmetry(l1: pd.Series, l2: pd.Series, l3: pd.Series) -> pd.Series:
    df = pd.DataFrame({'l1': l1, 'l2': l2, 'l3': l3}).dropna()
    df = df[df.max(axis=1) >= 1.0]
    if df.empty:
        return pd.Series(dtype=float)
    i_avg = df.mean(axis=1)
    return df.sub(i_avg, axis=0).abs().max(axis=1) / i_avg * 100


def _filter_powered(data: dict[str, pd.Series]) -> dict[str, pd.Series]:
    """Remove timestamps where voltage < 100V on all phases (outage)."""
    voltages = [data.get(k, pd.Series()) for k in
                ('voltage_l1', 'voltage_l2', 'voltage_l3')]
    powered = None
    for v in voltages:
        if not v.empty:
            mask = v > 100.0
            powered = mask if powered is None else powered | mask
    if powered is None:
        return data
    powered_times = powered[powered].index
    return {k: (s[s.index.isin(powered_times)] if not s.empty else s)
            for k, s in data.items()}


# ─── Channel analysis ────────────────────────────────────────────────────────

def analyze_channel(data: dict[str, pd.Series],
                    channel: int,
                    voltage_nominal: int,
                    missing: list[str]) -> ChannelResult:
    g = GOST
    # 380V 3-phase Russian network: phase nominal = 220V (380/√3 ≈ 219.4 → 220V per GOST)
    # 220V single-phase: nominal = 220V
    u_nom = 220.0 if voltage_nominal == 380 else float(voltage_nominal)

    result = ChannelResult(
        channel=channel,
        voltage_nominal=voltage_nominal,
        missing_params=missing,
        has_data=any(not s.empty for s in data.values()),
    )

    # Voltage
    for phase, key in [('L1', 'voltage_l1'), ('L2', 'voltage_l2'), ('L3', 'voltage_l3')]:
        s = data.get(key, pd.Series(dtype=float))
        dev = _voltage_dev_pct(s, u_nom) if not s.empty else s
        result.voltage.append(_metric(
            f'Отклонение напряжения {phase}', '%', dev,
            gost_limit=g['voltage_dev_normal'], limit_type='abs'))
        result.voltage.append(_metric(f'Напряжение {phase}', 'В', s))

    # Asymmetry
    k2u = _asymmetry_k2u(
        data.get('voltage_l1', pd.Series()),
        data.get('voltage_l2', pd.Series()),
        data.get('voltage_l3', pd.Series()),
    )
    result.asymmetry['voltage'] = _metric(
        'Несимметрия напряжения K2U', '%', k2u,
        gost_limit=g['asymmetry_normal'], limit_type='max')

    # Current
    for phase, key in [('L1', 'current_l1'), ('L2', 'current_l2'), ('L3', 'current_l3')]:
        s = data.get(key, pd.Series(dtype=float))
        result.current.append(_metric(f'Ток {phase}', 'А', s))

    ki = _current_asymmetry(
        data.get('current_l1', pd.Series()),
        data.get('current_l2', pd.Series()),
        data.get('current_l3', pd.Series()),
    )
    result.asymmetry['current'] = _metric('Несимметрия токов', '%', ki)

    # Power
    for name, key, unit in [
        ('Активная мощность P', 'p_total', 'Вт'),
        ('Реактивная мощность Q', 'q_total', 'вар'),
        ('Полная мощность S', 's_total', 'ВА'),
    ]:
        result.power[key] = _metric(name, unit, data.get(key, pd.Series(dtype=float)))

    # Power factor
    pf = data.get('pf_total', pd.Series(dtype=float))
    pf = pf[pf.abs() <= 1.0] if not pf.empty else pf
    result.power_factor = _metric(
        'Коэффициент мощности (cos φ)', '', pf,
        gost_limit=g['pf_min'], limit_type='min')
    pf_alarm_pct = float((pf < g['pf_alarm']).mean() * 100) if not pf.empty else 0
    result.power['pf_below_085_pct'] = round(pf_alarm_pct, 1)

    # Frequency
    freq = data.get('frequency', pd.Series(dtype=float))
    freq_dev = (freq - g['freq_nominal']).abs() if not freq.empty else freq
    result.frequency = _metric(
        'Отклонение частоты', 'Гц', freq_dev,
        gost_limit=g['freq_dev_normal'], limit_type='max')
    result.power['freq_abs'] = _metric('Частота', 'Гц', freq)

    # Energy
    for name, key, unit in [
        ('Активная энергия AP', 'energy_ap_total', 'Вт·ч'),
        ('Реактивная энергия RP', 'energy_rp_total', 'вар·ч'),
    ]:
        s = data.get(key, pd.Series(dtype=float))
        if not s.empty and len(s) >= 2:
            result.energy[key] = {
                'name': name,
                'start': round(float(s.iloc[0]), 1),
                'end':   round(float(s.iloc[-1]), 1),
                'total': round(float(s.iloc[-1] - s.iloc[0]), 1),
                'unit':  unit,
            }

    # Monthly power dynamics
    p_series = data.get('p_total', pd.Series(dtype=float))
    if not p_series.empty:
        monthly = p_series.resample('ME').mean()
        result.power['monthly'] = {
            ts.strftime('%b %Y'): round(float(v) / 1000, 1)
            for ts, v in monthly.items() if not np.isnan(v)
        }

    # Monthly PF dynamics
    pf_series = data.get('pf_total', pd.Series(dtype=float))
    if not pf_series.empty:
        pf_clean = pf_series[pf_series.abs() <= 1.0]
        if not pf_clean.empty:
            monthly_pf = pf_clean.resample('ME').mean()
            result.power['monthly_pf'] = {
                ts.strftime('%b %Y'): round(float(v), 3)
                for ts, v in monthly_pf.items() if not np.isnan(v)
            }

    # OptiMat T specific: neutral current, ground current
    for key, label in [('current_neutral', 'Ток нейтрали IN'),
                        ('current_ground',  'Ток замыкания Ig')]:
        s = data.get(key, pd.Series(dtype=float))
        if not s.empty:
            result.extra[key] = _metric(label, 'А', s)

    # THD напряжения (THD напряжения) — ГОСТ 32144-2013, лимит 8% для 0.4кВ
    thd_u_items = []
    for phase, key in [('L1', 'thd_voltage_l1'),
                        ('L2', 'thd_voltage_l2'),
                        ('L3', 'thd_voltage_l3')]:
        s = data.get(key, pd.Series(dtype=float))
        if not s.empty:
            m = _metric(f'THD напряжения {phase}', '%', s,
                        gost_limit=g['thd_voltage_normal'], limit_type='max')
            result.extra[key] = m
            thd_u_items.append(m)

    # THD тока (THD тока) — информационно, без нормы ГОСТ
    for phase, key in [('L1', 'thd_current_l1'),
                        ('L2', 'thd_current_l2'),
                        ('L3', 'thd_current_l3')]:
        s = data.get(key, pd.Series(dtype=float))
        if not s.empty:
            result.extra[key] = _metric(f'THD тока {phase}', '%', s)

    # Нарушения THD напряжения
    for m in thd_u_items:
        if m.violations_pct and m.violations_pct > 0:
            result.extra.setdefault('thd_violations', True)

    return result


# ─── Main entry point ─────────────────────────────────────────────────────────

def run_device_report(
    device_name: str,
    device_type,           # DeviceType from device_registry
    folder_id: int,
    resolved_per_channel:  dict[int, dict[str, str]],   # {ch: {logical: uuid}}
    channel_voltages:      dict[int, int],               # {ch: voltage_nominal}
    channel_load_names:    dict[int, str] = None,        # {ch: load_name}
    date_from: datetime = None,
    date_to:   datetime = None,
    on_progress=None,      # callable(pct: int, msg: str) or None
) -> DeviceReport:
    """
    Main function. resolved_per_channel comes from param_resolver.
    """
    all_times = []
    total_records = 0

    report = DeviceReport(
        device_name=device_name,
        device_type=device_type.code,
        device_type_label=device_type.label,
        folder_id=folder_id,
        period_start=datetime.now(),
        period_end=datetime.now(),
        total_records=0,
        interval_hours=0,
    )

    def _prog(pct, msg=''):
        if on_progress:
            on_progress(pct, msg)

    load_names = channel_load_names or {}
    n_channels = len(resolved_per_channel)

    for idx, (ch, resolved) in enumerate(resolved_per_channel.items()):
        v_nom = channel_voltages.get(ch, 380)
        base = idx * 80 // n_channels
        step = 80 // n_channels

        # Find which expected params are missing (no UUID found)
        expected = set(device_type.params.keys())
        found = set(resolved.keys())
        missing = sorted(expected - found)

        # Load data
        _prog(base + step // 3, f"Загрузка данных канал {ch}…")
        data = load_all_series(resolved, date_from, date_to)
        _prog(base + step * 2 // 3, f"Расчёт показателей канал {ch}…")
        data = _filter_powered(data)

        # Collect times for period calculation
        for s in data.values():
            if not s.empty:
                all_times.extend(s.index.tolist())
                total_records += len(s)

        ch_result = analyze_channel(data, ch, v_nom, missing)
        ch_result.load_name = load_names.get(ch, '')
        report.channels.append(ch_result)

        # Collect violations
        _collect_violations(ch_result, report, ch, device_type.channels)

    # Period — если данных нет, показываем запрошенный диапазон, а не "сегодня"
    if all_times:
        report.period_start = min(all_times)
        report.period_end   = max(all_times)
        report.total_records = total_records
    elif date_from or date_to:
        report.period_start = date_from or date_to
        report.period_end   = date_to or date_from

    _prog(85, "Формирование рекомендаций…")
    # Interval hours (from ch1 voltage_l1)
    ch1_resolved = resolved_per_channel.get(1, {})
    uuid_v1 = ch1_resolved.get('voltage_l1')
    if uuid_v1:
        ref = load_series(uuid_v1, date_from, date_to)
        if len(ref) > 1:
            diffs = ref.index.to_series().diff().dropna()
            report.interval_hours = round(diffs.mean().total_seconds() / 3600, 2)
            # Detect outages: gaps > 3× median interval or voltage < 50V
            _detect_outages(report, ref)

    # Build recommendations
    try:
        from recommendations import build_recommendations
        report.recommendations = build_recommendations(report)
    except Exception:
        pass

    return report


def _detect_outages(report: DeviceReport, voltage_series: pd.Series):
    """Detect outage events: voltage < 50V or gaps > 3× median interval."""
    if voltage_series.empty:
        return
    # Gap-based detection
    diffs = voltage_series.index.to_series().diff().dropna()
    if diffs.empty:
        return
    median_gap = diffs.median()
    threshold = median_gap * 3
    big_gaps = diffs[diffs > threshold]
    for ts, gap in big_gaps.items():
        start = ts - gap
        report.outages.append({
            'start': start.strftime('%d.%m.%Y %H:%M'),
            'end':   ts.strftime('%d.%m.%Y %H:%M'),
            'duration_h': round(gap.total_seconds() / 3600, 1),
            'type': 'Пропуск данных / отключение',
        })
    # Low-voltage detection
    low = voltage_series[voltage_series < 50.0]
    if not low.empty:
        report.outages.append({
            'start': low.index[0].strftime('%d.%m.%Y %H:%M'),
            'end':   low.index[-1].strftime('%d.%m.%Y %H:%M'),
            'duration_h': round((low.index[-1] - low.index[0]).total_seconds() / 3600, 1),
            'type': 'Напряжение < 50 В (обесточивание)',
        })


def _collect_violations(ch: ChannelResult, report: DeviceReport,
                        ch_num: int, total_channels: int):
    prefix = f'Кан. {ch_num}: ' if total_channels > 1 else ''
    g = GOST

    v_asym = ch.asymmetry.get('voltage')
    if v_asym and v_asym.violations_pct and v_asym.violations_pct > 0:
        report.violations.append(
            f'{prefix}Несимметрия напряжения: среднее {v_asym.mean:.1f}%, '
            f'макс {v_asym.max:.1f}%, превышение {g["asymmetry_normal"]}% '
            f'— {v_asym.violations_pct:.1f}% времени')

    for m in ch.voltage:
        if 'Отклонение' in m.name and m.violations_pct and m.violations_pct > 0:
            report.violations.append(
                f'{prefix}{m.name}: среднее {m.mean:.1f}%, '
                f'макс {m.max:.1f}%, превышение ±{g["voltage_dev_normal"]}% '
                f'— {m.violations_pct:.1f}% времени')

    pf = ch.power_factor
    if pf and pf.violations_pct and pf.violations_pct > 0:
        report.violations.append(
            f'{prefix}cos φ ниже нормы ({g["pf_min"]}): '
            f'среднее {pf.mean:.3f}, '
            f'{pf.violations_pct:.1f}% времени < {pf.gost_limit}, '
            f'{ch.power.get("pf_below_085_pct", 0):.1f}% < {g["pf_alarm"]}')

    freq = ch.frequency
    if freq and freq.violations_pct and freq.violations_pct > 0:
        report.violations.append(
            f'{prefix}Отклонение частоты: макс {freq.max:.3f} Гц, '
            f'{freq.violations_pct:.1f}% времени > ±{g["freq_dev_normal"]} Гц')

    ki = ch.asymmetry.get('current')
    if ki and ki.mean > 20:
        report.warnings.append(
            f'{prefix}Высокая несимметрия токов: среднее {ki.mean:.1f}%, '
            f'макс {ki.max:.1f}%')

    g = GOST
    for key, label in [('thd_voltage_l1', 'THD напряжения L1'),
                        ('thd_voltage_l2', 'THD напряжения L2'),
                        ('thd_voltage_l3', 'THD напряжения L3')]:
        m = ch.extra.get(key)
        if m and m.violations_pct and m.violations_pct > 0:
            report.violations.append(
                f'{prefix}Гармоники напряжения {label}: среднее {m.mean:.1f}%, '
                f'макс {m.max:.1f}%, превышение {g["thd_voltage_normal"]}% '
                f'— {m.violations_pct:.1f}% времени')
