"""
Управление конфигурацией каналов для MAP3E / MAP12E.

Хранится в channel_config.json (рядом с main.py).
Формат:
{
  "61": {"type": "map3e", "channels": {"1": "3phase"}},
  "731": {"type": "map12e", "channels": {
      "1": "3phase",
      "2": "1phase_x3",
      "3": "3phase",
      "4": "3phase"
  }}
}
"""

import json
import os

_CONFIG_PATH = os.path.join(os.path.dirname(__file__), 'channel_config.json')

# Voltage nominal per channel type
VOLTAGE_BY_CHANNEL_TYPE = {
    '3phase':    380,
    '1phase_x3': 220,
}

CHANNEL_TYPE_LABELS = {
    '3phase':    'Трёхфазная нагрузка (380 В)',
    '1phase_x3': '3×Однофазные нагрузки (220 В)',
}


def _load() -> dict:
    if os.path.exists(_CONFIG_PATH):
        with open(_CONFIG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}


def _save(cfg: dict):
    with open(_CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def get_channel_config(folder_key: str) -> dict:
    """Returns channel config for the folder, or empty dict."""
    cfg = _load()
    return cfg.get(folder_key, {})


def set_channel_config(folder_key: str, device_type_code: str, channels: dict[str, str]):
    """
    Saves channel config. Preserves existing load_names.
    channels: {"1": "3phase", "2": "1phase_x3", ...}
    """
    cfg = _load()
    existing = cfg.get(folder_key, {})
    cfg[folder_key] = {
        'type': device_type_code,
        'channels': channels,
        'load_names': existing.get('load_names', {}),
    }
    _save(cfg)


def get_voltage_for_channel(folder_key: str, channel: int) -> int:
    """Returns nominal voltage (V) for channel, default 380."""
    cfg = get_channel_config(folder_key)
    ch_type = cfg.get('channels', {}).get(str(channel), '3phase')
    return VOLTAGE_BY_CHANNEL_TYPE.get(ch_type, 380)


def get_all_channel_types(folder_key: str, n_channels: int) -> dict[int, str]:
    """Returns {ch: channel_type_str} for all channels."""
    cfg = get_channel_config(folder_key)
    channels_cfg = cfg.get('channels', {})
    return {
        ch: channels_cfg.get(str(ch), '3phase')
        for ch in range(1, n_channels + 1)
    }


def set_load_names(folder_key: str, load_names: dict[str, str]):
    """Saves load names. load_names: {'1': 'Насосная ст. №1', '2': 'Компрессор'}"""
    cfg = _load()
    if folder_key not in cfg:
        cfg[folder_key] = {}
    cfg[folder_key]['load_names'] = load_names
    _save(cfg)


def get_load_name(folder_key: str, channel: int, default: str = '') -> str:
    """Returns load name for channel, or default."""
    cfg = get_channel_config(folder_key)
    return cfg.get('load_names', {}).get(str(channel), default)


def get_all_load_names(folder_key: str, n_channels: int) -> dict[int, str]:
    """Returns {ch: load_name} for all channels."""
    cfg = get_channel_config(folder_key)
    names = cfg.get('load_names', {})
    return {ch: names.get(str(ch), '') for ch in range(1, n_channels + 1)}
