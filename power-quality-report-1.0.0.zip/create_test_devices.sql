-- =============================================================================
-- Создание тестовых устройств OptiSmart MAP12E и MAP3E в GAUSS
-- для тестирования микросервиса Power Quality Report
--
-- Запуск Windows:
--   "C:\Program Files\PostgreSQL\14\bin\psql.exe" -U postgres -d ags -f create_test_devices.sql
-- Запуск Linux:
--   sudo -u postgres psql -d ags -f create_test_devices.sql
--
-- Скрипт идемпотентен (безопасно запускать повторно).
-- В конце выводит folder_id — обновите channel_config.json!
-- =============================================================================

DO $$
DECLARE
    -- Фиксированные UUID
    v_ctrl_map12e_uuid UUID := 'aaaa0000-0001-0000-0000-000000000000'; -- UnitId=1
    v_ctrl_map3e_uuid  UUID := 'aaaa0000-0002-0000-0000-000000000000'; -- UnitId=2
    v_map12e_dev_uuid  UUID := 'aaaa0002-0001-0000-0000-000000000000';
    v_map3e_dev_uuid   UUID := 'aaaa0002-0002-0000-0000-000000000000';
    v_rtu_driver_uuid  UUID := '56a840b3-cbf1-41a2-8c81-7e386c92f0ad';
    v_project_uuid     UUID := 'fb2f7d14-bbe9-4564-86bc-d6eed0c63568';

    v_struktura_id    BIGINT;
    v_map12e_id       BIGINT;
    v_map3e_id        BIGINT;
    v_param_uuid      UUID;
    v_trend_uuid      UUID;
    v_order           BIGINT;
    v_reg             INTEGER;
    v_ch              INTEGER;
    v_i               INTEGER;

    -- Параметры MAP12E Channel-1 base registers
    -- Для MAP12E Channel N: actual_reg = base_reg + (N-1)*4096
    -- Для MAP3E (1 канал): actual_reg = base_reg, НО energy address другой — переопределяем ниже

    -- lnames
    v_lnames TEXT[] := ARRAY[
        'voltage_l1','voltage_l2','voltage_l3',
        'voltage_l1l2','voltage_l2l3','voltage_l3l1',
        'voltage_peak_l1','voltage_peak_l2','voltage_peak_l3',
        'current_l1','current_l2','current_l3',
        'current_peak_l1','current_peak_l2','current_peak_l3',
        'frequency',
        'phase_angle_l1','phase_angle_l2','phase_angle_l3',
        'p_total','q_total','s_total','pf_total',
        'p_l1','q_l1','s_l1','pf_l1',
        'p_l2','q_l2','s_l2','pf_l2',
        'p_l3','q_l3','s_l3','pf_l3',
        'energy_ap_total','energy_an_total','energy_rp_total','energy_rn_total',
        'energy_ap_l1','energy_an_l1','energy_rp_l1','energy_rn_l1',
        'energy_ap_l2','energy_an_l2','energy_rp_l2','energy_rn_l2',
        'energy_ap_l3','energy_an_l3','energy_rp_l3','energy_rn_l3'
    ];

    -- base registers (MAP12E energy = 0x12xx)
    v_map12e_regs INTEGER[] := ARRAY[
        5136,5138,5140,
        5148,5149,5150,
        6160,6162,6164,
        5142,5144,5146,
        6168,6170,6172,
        4344,
        4345,4346,4347,
        4864,4872,4880,4284,
        4866,4874,4882,4285,
        4868,4876,4884,4286,
        4870,4878,4886,4287,
        4608,4624,4640,4656,
        4612,4628,4644,4660,
        4616,4632,4648,4664,
        4620,4636,4652,4668
    ];

    -- MAP3E energy = 0x1Axx (отличие от MAP12E)
    v_map3e_regs INTEGER[] := ARRAY[
        5136,5138,5140,
        5148,5149,5150,
        6160,6162,6164,
        5142,5144,5146,
        6168,6170,6172,
        4344,
        4345,4346,4347,
        4864,4872,4880,4284,
        4866,4874,4882,4285,
        4868,4876,4884,4286,
        4870,4878,4886,4287,
        6656,6672,6688,6704,
        6660,6676,6692,6708,
        6664,6680,6696,6712,
        6668,6684,6700,6716
    ];

    -- datatypes
    v_dtypes TEXT[] := ARRAY[
        'uint16','uint16','uint16',
        'uint16','uint16','uint16',
        'uint16','uint16','uint16',
        'uint16','uint16','uint16',
        'uint16','uint16','uint16',
        'uint16',
        'uint16','uint16','uint16',
        'int32','int32','uint32','int16',
        'int32','int32','uint32','int16',
        'int32','int32','uint32','int16',
        'int32','int32','uint32','int16',
        'uint32','uint32','uint32','uint32',
        'uint32','uint32','uint32','uint32',
        'uint32','uint32','uint32','uint32',
        'uint32','uint32','uint32','uint32'
    ];

    -- CntRegString (number of modbus registers)
    v_cnts INTEGER[] := ARRAY[
        1,1,1, 1,1,1, 1,1,1,
        1,1,1, 1,1,1,
        1,
        1,1,1,
        2,2,2,1,
        2,2,2,1,
        2,2,2,1,
        2,2,2,1,
        2,2,2,2,
        2,2,2,2,
        2,2,2,2,
        2,2,2,2
    ];

    -- gain (scaling factor)
    v_gains NUMERIC[] := ARRAY[
        0.01,0.01,0.01,
        0.01,0.01,0.01,
        0.01,0.01,0.01,
        0.016,0.016,0.016,
        0.016,0.016,0.016,
        0.01,
        0.1,0.1,0.1,
        0.00512,0.00512,0.00512,0.001,
        0.00512,0.00512,0.00512,0.001,
        0.00512,0.00512,0.00512,0.001,
        0.00512,0.00512,0.00512,0.001,
        0.00001,0.00001,0.00001,0.00001,
        0.00001,0.00001,0.00001,0.00001,
        0.00001,0.00001,0.00001,0.00001,
        0.00001,0.00001,0.00001,0.00001
    ];

    -- unit_id: 14=В, 6=А, 30=Гц, 3=°, 18=Вт, 16=вар, 15=В×А, 2=%, 43=кВт×ч
    v_units SMALLINT[] := ARRAY[
        14,14,14, 14,14,14, 14,14,14,
        6,6,6,    6,6,6,
        30,
        3,3,3,
        18,16,15,2,
        18,16,15,2,
        18,16,15,2,
        18,16,15,2,
        43,43,43,43,
        43,43,43,43,
        43,43,43,43,
        43,43,43,43
    ]::SMALLINT[];

BEGIN

-- ── 1. Найти раздел Структура ─────────────────────────────────────────────────
SELECT id INTO v_struktura_id
FROM admin.project_tree
WHERE ref_type_id = 17
  AND parent_id = (
      SELECT id FROM admin.project_tree
      WHERE project_uuid = v_project_uuid AND ref_type_id = 5
      LIMIT 1
  )
LIMIT 1;

IF v_struktura_id IS NULL THEN
    RAISE EXCEPTION 'Раздел Структура не найден. GAUSS не инициализирован.';
END IF;

-- ── 2. Источники данных Modbus RTU (по одному на устройство) ──────────────────
-- MAP12E — UnitId=1
INSERT INTO admin.controller (uuid, driver_uuid, parent_uuid, data)
VALUES (
    v_ctrl_map12e_uuid, v_rtu_driver_uuid, NULL,
    '[{"Name":"Port","Value":"COM1"},{"Name":"BaudRate","Value":"9600"},{"Name":"DataBits","Value":"8"},{"Name":"Parity","Value":"Net"},{"Name":"StopBits","Value":"1"},{"Name":"UnitId","Value":1},{"Name":"PingRegister","Value":"5136"},{"Name":"PingRegType","Value":"Input registers (4)"},{"Name":"PingRegDataType","Value":"uint16"},{"Name":"PeriodMS","Value":1000},{"Name":"ConnectionTimeoutMS","Value":10000},{"Name":"MaxMultipleReadRegisters","Value":10}]'
)
ON CONFLICT (uuid) DO NOTHING;

IF NOT EXISTS (SELECT 1 FROM admin.project_tree WHERE ref_uuid = v_ctrl_map12e_uuid AND ref_type_id = 4) THEN
    INSERT INTO admin.project_tree (name, parent_id, project_uuid, ref_type_id, ref_uuid, "order")
    VALUES ('Modbus RTU MAP12E [TEST]', v_struktura_id, v_project_uuid, 4, v_ctrl_map12e_uuid, 100);
END IF;

-- MAP3E — UnitId=2
INSERT INTO admin.controller (uuid, driver_uuid, parent_uuid, data)
VALUES (
    v_ctrl_map3e_uuid, v_rtu_driver_uuid, NULL,
    '[{"Name":"Port","Value":"COM1"},{"Name":"BaudRate","Value":"9600"},{"Name":"DataBits","Value":"8"},{"Name":"Parity","Value":"Net"},{"Name":"StopBits","Value":"1"},{"Name":"UnitId","Value":2},{"Name":"PingRegister","Value":"5136"},{"Name":"PingRegType","Value":"Input registers (4)"},{"Name":"PingRegDataType","Value":"uint16"},{"Name":"PeriodMS","Value":1000},{"Name":"ConnectionTimeoutMS","Value":10000},{"Name":"MaxMultipleReadRegisters","Value":10}]'
)
ON CONFLICT (uuid) DO NOTHING;

IF NOT EXISTS (SELECT 1 FROM admin.project_tree WHERE ref_uuid = v_ctrl_map3e_uuid AND ref_type_id = 4) THEN
    INSERT INTO admin.project_tree (name, parent_id, project_uuid, ref_type_id, ref_uuid, "order")
    VALUES ('Modbus RTU MAP3E [TEST]', v_struktura_id, v_project_uuid, 4, v_ctrl_map3e_uuid, 102);
END IF;

-- ── 3. MAP12E (4 канала) ──────────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM admin.project_tree WHERE ref_uuid = v_map12e_dev_uuid AND ref_type_id = 2) THEN
    INSERT INTO admin.project_tree (name, parent_id, project_uuid, ref_type_id, ref_uuid, "order")
    VALUES ('OptiSmart MAP12E_1', v_struktura_id, v_project_uuid, 2, v_map12e_dev_uuid, 101);
END IF;
SELECT id INTO v_map12e_id FROM admin.project_tree WHERE ref_uuid = v_map12e_dev_uuid AND ref_type_id = 2 LIMIT 1;

IF NOT EXISTS (SELECT 1 FROM admin.project_tree WHERE parent_id = v_map12e_id AND ref_type_id = 3) THEN
FOR v_ch IN 1..4 LOOP
    v_order := (v_ch - 1) * 200;
    FOR v_i IN 1..array_length(v_lnames, 1) LOOP
        v_reg := v_map12e_regs[v_i] + (v_ch - 1) * 4096;
        v_param_uuid := gen_random_uuid();
        v_trend_uuid := gen_random_uuid();

        INSERT INTO admin.parameter (
            uuid, address, time_agent_id, data_type_id, unit_id,
            controller_uuid, is_template, is_edit_value, gain, "offset", display_name
        ) VALUES (
            v_param_uuid,
            '[{"Name":"Register","Value":"' || v_reg || '"},{"Name":"DataType","Value":"' || v_dtypes[v_i] ||
            '"},{"Name":"CntRegString","Value":' || v_cnts[v_i] ||
            '},{"Name":"RegType","Value":"Input registers (4)"},{"Name":"SwapBytes","Value":false},{"Name":"SwapRegisters","Value":false}]',
            0, 1000, v_units[v_i],
            v_ctrl_map12e_uuid, false, false, v_gains[v_i], 0,
            'Ch' || v_ch || ' ' || v_lnames[v_i]
        );

        INSERT INTO admin.trend (uuid, feature_id, parameter_uuid, interval_ms, is_active, date_create, max_record)
        VALUES (v_trend_uuid, 1, v_param_uuid, 60000, true,
                EXTRACT(EPOCH FROM NOW())::BIGINT * 1000, 1000000);

        INSERT INTO admin.project_tree (name, parent_id, project_uuid, ref_type_id, ref_uuid, "order")
        VALUES ('Ch' || v_ch || ' ' || v_lnames[v_i], v_map12e_id, v_project_uuid, 3, v_param_uuid, v_order);

        INSERT INTO admin.project_tree (name, parent_id, project_uuid, ref_type_id, ref_uuid, "order")
        VALUES ('Trend Ch' || v_ch || ' ' || v_lnames[v_i], v_map12e_id, v_project_uuid, 8, v_trend_uuid, v_order + 1);

        v_order := v_order + 2;
    END LOOP;
END LOOP;
END IF; -- end MAP12E params block

-- ── 4. MAP3E (1 канал) ────────────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM admin.project_tree WHERE ref_uuid = v_map3e_dev_uuid AND ref_type_id = 2) THEN
    INSERT INTO admin.project_tree (name, parent_id, project_uuid, ref_type_id, ref_uuid, "order")
    VALUES ('OptiSmart MAP3E_1', v_struktura_id, v_project_uuid, 2, v_map3e_dev_uuid, 102);
END IF;
SELECT id INTO v_map3e_id FROM admin.project_tree WHERE ref_uuid = v_map3e_dev_uuid AND ref_type_id = 2 LIMIT 1;

IF NOT EXISTS (SELECT 1 FROM admin.project_tree WHERE parent_id = v_map3e_id AND ref_type_id = 3) THEN
v_order := 0;
FOR v_i IN 1..array_length(v_lnames, 1) LOOP
    v_reg := v_map3e_regs[v_i];
    v_param_uuid := gen_random_uuid();
    v_trend_uuid := gen_random_uuid();

    INSERT INTO admin.parameter (
        uuid, address, time_agent_id, data_type_id, unit_id,
        controller_uuid, is_template, is_edit_value, gain, "offset", display_name
    ) VALUES (
        v_param_uuid,
        '[{"Name":"Register","Value":"' || v_reg || '"},{"Name":"DataType","Value":"' || v_dtypes[v_i] ||
        '"},{"Name":"CntRegString","Value":' || v_cnts[v_i] ||
        '},{"Name":"RegType","Value":"Input registers (4)"},{"Name":"SwapBytes","Value":false},{"Name":"SwapRegisters","Value":false}]',
        0, 1000, v_units[v_i],
        v_ctrl_map3e_uuid, false, false, v_gains[v_i], 0,
        v_lnames[v_i]
    );

    INSERT INTO admin.trend (uuid, feature_id, parameter_uuid, interval_ms, is_active, date_create, max_record)
    VALUES (v_trend_uuid, 1, v_param_uuid, 60000, true,
            EXTRACT(EPOCH FROM NOW())::BIGINT * 1000, 1000000);

    INSERT INTO admin.project_tree (name, parent_id, project_uuid, ref_type_id, ref_uuid, "order")
    VALUES (v_lnames[v_i], v_map3e_id, v_project_uuid, 3, v_param_uuid, v_order);

    INSERT INTO admin.project_tree (name, parent_id, project_uuid, ref_type_id, ref_uuid, "order")
    VALUES ('Trend ' || v_lnames[v_i], v_map3e_id, v_project_uuid, 8, v_trend_uuid, v_order + 1);

    v_order := v_order + 2;
END LOOP;
END IF; -- end MAP3E params block

-- ── 5. Итог ───────────────────────────────────────────────────────────────────
RAISE NOTICE '=== Test devices created ===';
RAISE NOTICE 'MAP12E: OptiSmart MAP12E_1 (UUID: aaaa0002-0001-0000-0000-000000000000)';
RAISE NOTICE 'MAP3E:  OptiSmart MAP3E_1  (UUID: aaaa0002-0002-0000-0000-000000000000)';
RAISE NOTICE 'channel_config.json already configured — no manual update needed.';

END $$;
