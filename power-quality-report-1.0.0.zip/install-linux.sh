#!/bin/bash
# Установка Power Quality Report на Linux-сервер
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

ok()   { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[!!]${NC} $1"; }
fail() { echo -e "${RED}[ERR]${NC} $1"; exit 1; }

echo "=== Установка Power Quality Report ==="
echo ""

# ── 1. Docker ─────────────────────────────────────────────────────────────────
if ! command -v docker &>/dev/null; then
    fail "Docker не установлен. Установите Docker Engine: https://docs.docker.com/engine/install/"
fi
DOCKER_VERSION=$(docker --version | grep -oP '\d+\.\d+' | head -1)
ok "Docker $DOCKER_VERSION"

if ! docker compose version &>/dev/null; then
    fail "Docker Compose (v2) не найден. Установите плагин docker-compose-plugin."
fi
ok "Docker Compose $(docker compose version --short)"

# ── 2. PostgreSQL ─────────────────────────────────────────────────────────────
PG_HOST="${PG_HOST:-localhost}"
PG_PORT="${PG_PORT:-5432}"
PG_USER="${PG_USER:-postgres}"
PG_PASS="${PG_PASS:-postgres}"
PG_DB="${PG_DB:-ags}"

echo ""
echo "Проверка PostgreSQL на ${PG_HOST}:${PG_PORT} (БД: ${PG_DB})..."

if ! command -v psql &>/dev/null; then
    # psql нет — проверяем через TCP
    if ! bash -c "echo >/dev/tcp/${PG_HOST}/${PG_PORT}" 2>/dev/null; then
        fail "PostgreSQL недоступен на ${PG_HOST}:${PG_PORT}. Установите и запустите PostgreSQL перед установкой микросервиса."
    fi
    warn "psql не найден, проверена только доступность порта ${PG_PORT}"
else
    if ! PGPASSWORD="${PG_PASS}" psql -h "${PG_HOST}" -p "${PG_PORT}" -U "${PG_USER}" -d "${PG_DB}" -c "SELECT 1" &>/dev/null; then
        fail "Не удалось подключиться к PostgreSQL (${PG_USER}@${PG_HOST}:${PG_PORT}/${PG_DB}). Проверьте что GAUSS установлен и PostgreSQL запущен."
    fi
    ok "PostgreSQL доступен, БД '${PG_DB}' найдена"
fi

# ── 3. pg_hba.conf — разрешаем Docker-подсеть ─────────────────────────────────
echo ""
echo "Настройка pg_hba.conf для Docker..."

PG_HBA=$(find /etc/postgresql -name pg_hba.conf 2>/dev/null | head -1)
if [ -z "$PG_HBA" ]; then
    PG_HBA=$(su - postgres -c "psql -t -c 'SHOW hba_file'" 2>/dev/null | tr -d ' ')
fi

DOCKER_RULE="host    all             all             172.16.0.0/12           scram-sha-256"

if [ -n "$PG_HBA" ] && [ -f "$PG_HBA" ]; then
    if grep -q "172.16.0.0/12" "$PG_HBA"; then
        ok "Правило для Docker уже есть в pg_hba.conf"
    else
        cp "$PG_HBA" "${PG_HBA}.bak"
        echo "$DOCKER_RULE" >> "$PG_HBA"
        # Перезагружаем конфиг PostgreSQL
        if command -v pg_ctlcluster &>/dev/null; then
            PG_VER=$(ls /etc/postgresql/ | sort -V | tail -1)
            PG_CLUSTER=$(ls /etc/postgresql/"$PG_VER"/ | head -1)
            pg_ctlcluster "$PG_VER" "$PG_CLUSTER" reload
        else
            su - postgres -c "pg_ctl reload" 2>/dev/null || systemctl reload postgresql 2>/dev/null || true
        fi
        ok "Добавлено правило Docker в pg_hba.conf (резервная копия: ${PG_HBA}.bak)"
    fi
else
    warn "pg_hba.conf не найден автоматически. Добавьте вручную:"
    echo ""
    echo "    $DOCKER_RULE"
    echo ""
    echo "    Затем: systemctl reload postgresql"
    echo ""
    read -rp "Продолжить после ручной настройки? [y/N] " confirm
    [[ "$confirm" =~ ^[Yy]$ ]] || fail "Установка прервана"
fi

# ── 4. Уже установлен? ────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if docker compose ps --status running 2>/dev/null | grep -q "pq_report"; then
    ok "Микросервис уже запущен — ничего делать не нужно."
    exit 0
fi

# ── 5. Сборка и запуск ────────────────────────────────────────────────────────
echo ""
echo "Сборка и запуск контейнеров..."

export PG_HOST PG_PORT PG_USER PG_PASS PG_DB

docker compose build --no-cache
docker compose up -d

echo ""
echo "Проверка запуска..."
sleep 8

if docker compose ps | grep -q "Up"; then
    ok "Контейнеры запущены"
else
    fail "Контейнеры не запустились. Проверьте: docker compose logs"
fi

# ── 6. systemd-сервис для автозапуска ─────────────────────────────────────────
echo ""
echo "Настройка автозапуска..."

SERVICE_FILE="/etc/systemd/system/power-quality-report.service"

cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=Power Quality Report
After=docker.service network-online.target
Requires=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=${SCRIPT_DIR}
ExecStart=/usr/bin/docker compose up -d
ExecStop=/usr/bin/docker compose down
TimeoutStartSec=120

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable power-quality-report.service
ok "Автозапуск настроен (systemd: power-quality-report.service)"

# ── 7. Регистрация веб-страницы в GAUSS ──────────────────────────────────────
# Регистрация выполняется автоматически микросервисом при первом запуске
# через _ensure_gauss_page() в main.py (отдельный UUID на каждый проект GAUSS)
ok "Веб-страница будет зарегистрирована автоматически при первом запуске сервиса"

# ── 8. Проверка HTTP ──────────────────────────────────────────────────────────
sleep 3
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8000/ 2>/dev/null || echo "000")
if [ "$HTTP_CODE" = "200" ]; then
    ok "Микросервис отвечает на http://localhost:8000/"
else
    warn "HTTP ответ: ${HTTP_CODE}. Проверьте: docker compose logs pq_report_app"
fi

echo ""
echo "=== Установка завершена ==="
echo "Сервис: http://localhost:8000/"
echo "Логи:   docker compose logs -f"
echo "Стоп:   docker compose down"
