#!/usr/bin/env python3
"""
Создание/удаление тестовой среды Power Quality Microservice.

Создаёт 4 тестовых устройства в GAUSS и генерирует архивные данные.

Использование:
    python setup_test_env.py create [--days 30] [--interval 15]
    python setup_test_env.py delete
"""

import argparse
import json
import os
import random
import sys
import uuid
from datetime import datetime, timedelta

import psycopg2
import psycopg2.extras

from device_registry import DEVICES

# ── Подключения (читаем из env — те же переменные что у контейнера) ───────────
AGS_DB = dict(
    host    = os.environ.get('PG_HOST', 'localhost'),
    port    = int(os.environ.get('PG_PORT', 5432)),
    dbname  = os.environ.get('PG_DB',   'ags'),
    user    = os.environ.get('PG_USER', 'postgres'),
    password= os.environ.get('PG_PASS', 'postgres'),
)

# ── Описание устройств (фиксированные UUID для портируемости) ─────────────────
# driver_type: 'rtu' | 'tcp' — UUID драйвера определяется из БД при запуске
DEVICE_DEFS = [
    dict(key='map12e', name='OptiSmart MAP12E_1',
         ctrl_uuid='aaaa0000-0001-0000-0000-000000000000',
         dev_uuid ='aaaa0002-0001-0000-0000-000000000000',
         driver_type='rtu', unit_id=1, ctrl_order=100, dev_order=101),

    dict(key='map3e', name='OptiSmart MAP3E_1',
         ctrl_uuid='aaaa0000-0002-0000-0000-000000000000',
         dev_uuid ='aaaa0002-0002-0000-0000-000000000000',
         driver_type='rtu', unit_id=2, ctrl_order=102, dev_order=103),

    dict(key='optimat', name='OptiMat T_1',
         ctrl_uuid='aaaa0000-0003-0000-0000-000000000000',
         dev_uuid ='aaaa0002-0003-0000-0000-000000000000',
         driver_type='rtu', unit_id=3, ctrl_order=104, dev_order=105),

    dict(key='optimer', name='OptiMer M500_1',
         ctrl_uuid='aaaa0000-0004-0000-0000-000000000000',
         dev_uuid ='aaaa0002-0004-0000-0000-000000000000',
         driver_type='tcp', unit_id=4, ctrl_order=106, dev_order=107),
]

# ── Свойства параметров: (dtype, cnt_regs, gain, unit_id) ─────────────────────
# unit_id: 14=В, 6=А, 30=Гц, 3=°, 18=Вт, 16=вар, 15=В×А, 2=%, 43=кВт×ч, 1=нет
def _param_props(dev_key: str, lname: str) -> tuple:
    """Returns (dtype, cnt_regs, gain, unit_id)."""
    # OptiMer использует float-регистры (IEEE 754), gain=1.0
    if dev_key == 'optimer':
        if 'energy_' in lname:
            return ('float', 2, 1.0, 43)
        if lname.startswith('voltage_l') and ('l2' in lname[10:] or 'l3' in lname[10:] or lname in ('voltage_l1l2','voltage_l2l3','voltage_l3l1')):
            return ('float', 2, 1.0, 14)
        if lname.startswith('voltage_'):
            return ('float', 2, 1.0, 14)
        if lname.startswith('current_'):
            return ('float', 2, 1.0, 6)
        if lname == 'frequency':
            return ('float', 2, 1.0, 30)
        if lname.startswith('p_'):
            return ('float', 2, 1.0, 18)
        if lname.startswith('q_'):
            return ('float', 2, 1.0, 16)
        if lname.startswith('s_'):
            return ('float', 2, 1.0, 15)
        if lname.startswith('pf_'):
            return ('float', 2, 1.0, 2)
        return ('float', 2, 1.0, 1)

    # OptiMat T — смешанные типы
    if dev_key == 'optimat':
        if lname.startswith('current_'):
            return ('uint16', 1, 0.01, 6)
        if lname.startswith('voltage_'):
            return ('uint16', 1, 0.1, 14)
        if lname.startswith('p_'):
            return ('int16', 1, 0.001, 18)
        if lname.startswith('q_'):
            return ('int16', 1, 0.001, 16)
        if lname.startswith('s_'):
            return ('uint16', 1, 0.001, 15)
        if lname.startswith('pf_'):
            return ('uint16', 1, 0.001, 2)
        if lname == 'frequency':
            return ('uint16', 1, 0.01, 30)
        if 'energy_' in lname:
            return ('int64', 4, 0.001, 43)
        if lname.startswith('status_'):
            return ('uint16', 1, 1.0, 1)
        if 'thd_' in lname:
            return ('uint16', 1, 0.01, 2)
        return ('uint16', 1, 1.0, 1)

    # MAP3E / MAP12E
    if lname.startswith('voltage_') and ('l1l' in lname or 'l2l' in lname or 'l3l' in lname):
        return ('uint16', 1, 0.01, 14)
    if lname.startswith('voltage_peak_'):
        return ('uint16', 1, 0.01, 14)
    if lname.startswith('voltage_l'):
        return ('uint16', 1, 0.01, 14)
    if lname.startswith('current_peak_'):
        return ('uint16', 1, 0.016, 6)
    if lname.startswith('current_'):
        return ('uint16', 1, 0.016, 6)
    if lname == 'frequency':
        return ('uint16', 1, 0.01, 30)
    if lname.startswith('phase_angle_'):
        return ('uint16', 1, 0.1, 3)
    if lname in ('p_total','p_l1','p_l2','p_l3'):
        return ('int32', 2, 0.00512, 18)
    if lname in ('q_total','q_l1','q_l2','q_l3'):
        return ('int32', 2, 0.00512, 16)
    if lname in ('s_total','s_l1','s_l2','s_l3'):
        return ('uint32', 2, 0.00512, 15)
    if lname in ('pf_total','pf_l1','pf_l2','pf_l3'):
        return ('int16', 1, 0.001, 2)
    if 'energy_' in lname:
        return ('uint32', 2, 0.00001, 43)
    return ('uint16', 1, 1.0, 1)


# ── Генераторы реалистичных значений (инженерные единицы) ─────────────────────
def _gen_value(lname: str, prev: float = None) -> float:
    n = lname

    # Фазные напряжения (220 В)
    if n in ('voltage_l1', 'voltage_l2', 'voltage_l3'):
        return round(random.gauss(220.0, 4.0), 2)
    # Линейные напряжения (380 В)
    if n in ('voltage_l1l2', 'voltage_l2l3', 'voltage_l3l1'):
        return round(random.gauss(380.0, 7.0), 2)
    # Пиковые напряжения (220*√2 ≈ 311)
    if 'voltage_peak' in n:
        return round(random.gauss(311.0, 6.0), 2)

    # Токи
    if n in ('current_l1', 'current_l2', 'current_l3'):
        return round(max(0.1, random.gauss(8.0, 2.0)), 3)
    if 'current_peak' in n:
        return round(max(0.1, random.gauss(11.3, 3.0)), 3)
    if n in ('current_neutral', 'current_ground'):
        return round(max(0.0, random.gauss(0.3, 0.2)), 3)

    # Частота
    if n == 'frequency':
        return round(random.gauss(50.0, 0.03), 3)

    # Углы фаз
    if 'phase_angle' in n:
        return round(random.gauss(0.0, 5.0), 1)

    # Активная мощность по фазам ~700 Вт, суммарная ~2100 Вт
    if n in ('p_l1', 'p_l2', 'p_l3'):
        return round(random.gauss(700.0, 150.0), 1)
    if n == 'p_total':
        return round(random.gauss(2100.0, 400.0), 1)

    # Реактивная мощность
    if n in ('q_l1', 'q_l2', 'q_l3'):
        return round(random.gauss(250.0, 80.0), 1)
    if n == 'q_total':
        return round(random.gauss(750.0, 200.0), 1)

    # Полная мощность
    if n in ('s_l1', 's_l2', 's_l3'):
        return round(random.gauss(750.0, 150.0), 1)
    if n == 's_total':
        return round(random.gauss(2250.0, 400.0), 1)

    # Коэффициент мощности
    if 'pf_' in n:
        return round(min(1.0, max(0.70, random.gauss(0.92, 0.04))), 3)

    # Энергия — накопительный счётчик
    if 'energy_ap' in n or 'energy_an' in n:
        base = prev if prev is not None else 0.0
        return round(base + random.uniform(0.003, 0.05), 4)  # кВт·ч за интервал
    if 'energy_rp' in n or 'energy_rn' in n:
        base = prev if prev is not None else 0.0
        return round(base + random.uniform(0.001, 0.02), 4)

    # THD напряжения ~3%, тока ~8%
    if 'thd_voltage' in n:
        return round(max(0.5, random.gauss(3.0, 0.8)), 2)
    if 'thd_current' in n:
        return round(max(1.0, random.gauss(8.0, 2.0)), 2)

    # Статусы
    if 'status_work' in n:
        return 1.0
    if 'status_alarm' in n:
        return 0.0

    return round(random.gauss(100.0, 10.0), 2)


# ── Helpers ───────────────────────────────────────────────────────────────────
def _make_address(reg: int, dtype: str, cnt: int) -> str:
    return json.dumps([
        {"Name": "Register",      "Value": str(reg)},
        {"Name": "DataType",      "Value": dtype},
        {"Name": "CntRegString",  "Value": cnt},
        {"Name": "RegType",       "Value": "Input registers (4)"},
        {"Name": "SwapBytes",     "Value": False},
        {"Name": "SwapRegisters", "Value": False},
    ])


def _controller_data(driver_type: str, unit_id: int) -> str:
    if driver_type == 'tcp':
        return json.dumps([
            {"Name": "IPAddress",             "Value": "192.168.1.100"},
            {"Name": "Port",                  "Value": "502"},
            {"Name": "UnitId",                "Value": unit_id},
            {"Name": "PingRegister",          "Value": "16652"},
            {"Name": "PingRegType",           "Value": "Input registers (4)"},
            {"Name": "PingRegDataType",       "Value": "float"},
            {"Name": "PeriodMS",              "Value": 1000},
            {"Name": "ConnectionTimeoutMS",   "Value": 10000},
            {"Name": "MaxMultipleReadRegisters", "Value": 10},
        ])
    else:
        return json.dumps([
            {"Name": "Port",                  "Value": "COM1"},
            {"Name": "BaudRate",              "Value": "9600"},
            {"Name": "DataBits",              "Value": "8"},
            {"Name": "Parity",                "Value": "None"},
            {"Name": "StopBits",              "Value": "1"},
            {"Name": "UnitId",                "Value": unit_id},
            {"Name": "PingRegister",          "Value": "5136"},
            {"Name": "PingRegType",           "Value": "Input registers (4)"},
            {"Name": "PingRegDataType",       "Value": "uint16"},
            {"Name": "PeriodMS",              "Value": 1000},
            {"Name": "ConnectionTimeoutMS",   "Value": 10000},
            {"Name": "MaxMultipleReadRegisters", "Value": 10},
        ])


# ── Автоопределение параметров из БД ──────────────────────────────────────────
def _list_projects(cur) -> list[tuple]:
    """Возвращает список (project_uuid, name) реальных проектов GAUSS."""
    cur.execute("""
        SELECT project_uuid, name FROM admin.project_tree
        WHERE ref_type_id = 5
          AND project_uuid != '00000000-0000-0000-0000-000000000000'::uuid
        ORDER BY name
    """)
    return [(str(r[0]), r[1]) for r in cur.fetchall()]


def _resolve_project(cur, project_name: str = None) -> str:
    """
    Возвращает project_uuid по имени проекта.
    Если имя не задано и проект один — берёт его автоматически.
    Если проектов несколько — показывает меню выбора.
    """
    projects = _list_projects(cur)
    if not projects:
        print("[ERR] Корневой узел GAUSS не найден. GAUSS не инициализирован.")
        sys.exit(1)

    # Поиск по имени
    if project_name:
        match = [p for p in projects if p[1].lower() == project_name.lower()]
        if not match:
            names = ', '.join(p[1] for p in projects)
            print(f"[ERR] Проект '{project_name}' не найден. Доступные: {names}")
            sys.exit(1)
        return match[0][0]

    # Один проект — берём автоматически
    if len(projects) == 1:
        print(f"[OK] Проект: {projects[0][1]}")
        return projects[0][0]

    # Несколько проектов — интерактивный выбор
    print("\nДоступные проекты GAUSS:")
    for i, (uuid_, name) in enumerate(projects, 1):
        print(f"  [{i}] {name}")
    while True:
        try:
            choice = int(input(f"Выберите проект (1-{len(projects)}): "))
            if 1 <= choice <= len(projects):
                chosen = projects[choice - 1]
                print(f"[OK] Выбран проект: {chosen[1]}")
                return chosen[0]
        except (ValueError, KeyboardInterrupt):
            pass
        print(f"     Введите число от 1 до {len(projects)}")


def _resolve_db_params(cur, project_name: str = None) -> tuple:
    """
    Возвращает (project_uuid, rtu_driver_uuid, tcp_driver_uuid).
    Все значения берутся из БД — не захардкожены.
    """
    project_uuid = _resolve_project(cur, project_name)

    # Modbus RTU driver UUID
    cur.execute("SELECT uuid FROM admin.driver WHERE driver_type ILIKE '%RTU%' LIMIT 1")
    row = cur.fetchone()
    rtu_uuid = str(row[0]) if row else None

    # Modbus TCP driver UUID
    cur.execute("SELECT uuid FROM admin.driver WHERE driver_type ILIKE '%TCP%' LIMIT 1")
    row = cur.fetchone()
    tcp_uuid = str(row[0]) if row else None

    # Если не нашли по driver_type — берём что есть
    if not rtu_uuid or not tcp_uuid:
        cur.execute("SELECT uuid, driver_type FROM admin.driver LIMIT 10")
        drivers = cur.fetchall()
        if not drivers:
            print("[ERR] Ни одного драйвера в admin.driver. Проверьте установку GAUSS.")
            sys.exit(1)
        fallback = str(drivers[0][0])
        if not rtu_uuid:
            rtu_uuid = fallback
            print(f"[WARN] Modbus RTU драйвер не найден — используем: {drivers[0][1]} ({fallback})")
        if not tcp_uuid:
            tcp_uuid = rtu_uuid
            print(f"[WARN] Modbus TCP драйвер не найден — используем RTU как fallback")

    print(f"[OK] project_uuid : {project_uuid}")
    print(f"[OK] RTU driver   : {rtu_uuid}")
    print(f"[OK] TCP driver   : {tcp_uuid}")
    return project_uuid, rtu_uuid, tcp_uuid


# ── CREATE ────────────────────────────────────────────────────────────────────
def create(days: int = 30, interval_min: int = 15, project_name: str = None):
    conn = psycopg2.connect(**AGS_DB)
    cur = conn.cursor()

    project_uuid, rtu_uuid, tcp_uuid = _resolve_db_params(cur, project_name)

    def _driver_uuid(dev: dict) -> str:
        return tcp_uuid if dev['driver_type'] == 'tcp' else rtu_uuid

    # Найти Структуру главного проекта
    cur.execute("""
        SELECT id FROM admin.project_tree
        WHERE ref_type_id = 17
          AND parent_id = (SELECT id FROM admin.project_tree
                           WHERE project_uuid = %s::uuid AND ref_type_id = 5 LIMIT 1)
        LIMIT 1
    """, (project_uuid,))
    row = cur.fetchone()
    if not row:
        print("[ERR] Раздел Структура не найден. GAUSS не инициализирован.")
        sys.exit(1)
    struktura_id = row[0]

    now = datetime.now().replace(second=0, microsecond=0)
    date_from = now - timedelta(days=days)
    timestamps = [date_from + timedelta(minutes=i * interval_min)
                  for i in range(int(days * 24 * 60 / interval_min))]

    total_log_rows = 0

    for dev in DEVICE_DEFS:
        key      = dev['key']
        dt_obj   = DEVICES[key]
        ctrl_uuid = dev['ctrl_uuid']
        dev_uuid  = dev['dev_uuid']
        drv_uuid  = _driver_uuid(dev)
        print(f"\n[>>] {dev['name']} ({len(dt_obj.params)} параметров, "
              f"{dt_obj.channels} канал(а/ов))")

        # ── Контроллер ────────────────────────────────────────────────────────
        cur.execute("""
            INSERT INTO admin.controller (uuid, driver_uuid, parent_uuid, data)
            VALUES (%s, %s, NULL, %s)
            ON CONFLICT (uuid) DO NOTHING
        """, (ctrl_uuid, drv_uuid, _controller_data(dev['driver_type'], dev['unit_id'])))

        if not _tree_exists(cur, ctrl_uuid, 4):
            cur.execute("""
                INSERT INTO admin.project_tree
                    (name, parent_id, project_uuid, ref_type_id, ref_uuid, "order")
                VALUES (%s, %s, %s::uuid, 4, %s::uuid, %s)
            """, (f"{dev['name']} [TEST SRC]", struktura_id,
                  project_uuid, ctrl_uuid, dev['ctrl_order']))

        # ── Папка устройства ──────────────────────────────────────────────────
        if not _tree_exists(cur, dev_uuid, 2):
            cur.execute("""
                INSERT INTO admin.project_tree
                    (name, parent_id, project_uuid, ref_type_id, ref_uuid, "order")
                VALUES (%s, %s, %s::uuid, 2, %s::uuid, %s)
            """, (dev['name'], struktura_id, project_uuid, dev_uuid, dev['dev_order']))

        cur.execute("SELECT id FROM admin.project_tree WHERE ref_uuid = %s::uuid AND ref_type_id = 2 LIMIT 1",
                    (dev_uuid,))
        folder_id = cur.fetchone()[0]

        # Пропускаем если параметры уже есть
        cur.execute("SELECT COUNT(*) FROM admin.project_tree WHERE parent_id = %s AND ref_type_id = 3", (folder_id,))
        if cur.fetchone()[0] > 0:
            print(f"  [--] Параметры уже существуют — пропускаем создание.")
            conn.commit()
            continue

        # ── Параметры и тренды ────────────────────────────────────────────────
        n_ch = dt_obj.channels
        ch_offset = dt_obj.channel_offset

        # {(channel, lname): (param_uuid, trend_uuid)}
        param_map: dict[tuple, tuple] = {}

        param_rows  = []
        trend_rows  = []
        ptree_rows  = []
        epoch_ms = int(now.timestamp() * 1000)

        order = 0
        for ch in range(1, n_ch + 1):
            for lname, base_reg in dt_obj.params.items():
                reg = base_reg + (ch - 1) * ch_offset
                dtype, cnt, gain, unit_id = _param_props(key, lname)

                p_uuid = str(uuid.uuid4())
                t_uuid = str(uuid.uuid4())
                display = f"Ch{ch} {lname}" if n_ch > 1 else lname
                label   = f"Trend Ch{ch} {lname}" if n_ch > 1 else f"Trend {lname}"

                param_rows.append((
                    p_uuid, _make_address(reg, dtype, cnt),
                    0, 1000, unit_id, ctrl_uuid, False, False, gain, 0, display
                ))
                trend_rows.append((t_uuid, 1, p_uuid, 60000, False, epoch_ms, 10000000))
                ptree_rows.append((display, folder_id, project_uuid, 3, p_uuid, order))
                ptree_rows.append((label,   folder_id, project_uuid, 8, t_uuid, order + 1))
                param_map[(ch, lname)] = (p_uuid, t_uuid)
                order += 2

        psycopg2.extras.execute_values(cur, """
            INSERT INTO admin.parameter
                (uuid, address, time_agent_id, data_type_id, unit_id,
                 controller_uuid, is_template, is_edit_value, gain, "offset", display_name)
            VALUES %s
        """, param_rows)

        psycopg2.extras.execute_values(cur, """
            INSERT INTO admin.trend
                (uuid, feature_id, parameter_uuid, interval_ms, is_active, date_create, max_record)
            VALUES %s
        """, trend_rows)

        psycopg2.extras.execute_values(cur, """
            INSERT INTO admin.project_tree
                (name, parent_id, project_uuid, ref_type_id, ref_uuid, "order")
            VALUES %s
        """, [(r[0], r[1], r[2], r[3], r[4], r[5]) for r in ptree_rows])

        print(f"  [OK] Создано {len(param_rows)} параметров, {len(trend_rows)} трендов")

        # ── Генерация архивных данных ──────────────────────────────────────────
        print(f"  [..] Generating data: {len(timestamps)} pts x {len(param_map)} series...")

        # Предварительные значения для накопительных счётчиков
        prev_values: dict[tuple, float] = {}

        BATCH = 5000
        log_batch = []

        for ts in timestamps:
            for (ch, lname), (p_uuid, t_uuid) in param_map.items():
                prev = prev_values.get((ch, lname))
                val = _gen_value(lname, prev)
                prev_values[(ch, lname)] = val

                log_batch.append((
                    str(uuid.uuid4()), t_uuid, str(val), '', ts
                ))

                if len(log_batch) >= BATCH:
                    psycopg2.extras.execute_values(cur, """
                        INSERT INTO admin.trend_log
                            (uuid, trend_uuid, value, status, date_create)
                        VALUES %s
                    """, log_batch)
                    log_batch.clear()
                    conn.commit()

        if log_batch:
            psycopg2.extras.execute_values(cur, """
                INSERT INTO admin.trend_log
                    (uuid, trend_uuid, value, status, date_create)
                VALUES %s
            """, log_batch)

        conn.commit()
        dev_records = len(timestamps) * len(param_map)
        total_log_rows += dev_records
        print(f"  [OK] Вставлено {dev_records:,} записей trend_log")

    cur.close()
    conn.close()

    print(f"\n=== Готово ===")
    print(f"Всего записей trend_log: {total_log_rows:,}")
    print(f"Период: {days} дней, интервал: {interval_min} мин")


# ── DELETE ────────────────────────────────────────────────────────────────────
def delete(project_name: str = None):
    conn = psycopg2.connect(**AGS_DB)
    cur = conn.cursor()

    project_uuid = _resolve_project(cur, project_name)
    print(f"[..] Удаление тестовых устройств из проекта {project_uuid}")


    all_ctrl_uuids = [d['ctrl_uuid'] for d in DEVICE_DEFS]
    all_dev_uuids  = [d['dev_uuid']  for d in DEVICE_DEFS]

    print("[..] Удаление trend_log...")
    cur.execute("""
        DELETE FROM admin.trend_log
        WHERE trend_uuid IN (
            SELECT uuid FROM admin.trend
            WHERE parameter_uuid IN (
                SELECT uuid FROM admin.parameter
                WHERE controller_uuid = ANY(%s::uuid[])
            )
        )
    """, (all_ctrl_uuids,))
    print(f"  [OK] Удалено {cur.rowcount} записей trend_log")

    print("[..] Удаление трендов...")
    cur.execute("""
        DELETE FROM admin.trend
        WHERE parameter_uuid IN (
            SELECT uuid FROM admin.parameter WHERE controller_uuid = ANY(%s::uuid[])
        )
    """, (all_ctrl_uuids,))
    print(f"  [OK] Удалено {cur.rowcount} трендов")

    print("[..] Удаление нод project_tree (параметры и тренды)...")
    # Удаляем из папок устройств
    cur.execute("""
        DELETE FROM admin.project_tree
        WHERE parent_id IN (
            SELECT id FROM admin.project_tree WHERE ref_uuid = ANY(%s::uuid[]) AND ref_type_id = 2
        )
    """, (all_dev_uuids,))
    print(f"  [OK] Удалено {cur.rowcount} нод параметров/трендов")

    print("[..] Удаление параметров...")
    cur.execute("DELETE FROM admin.parameter WHERE controller_uuid = ANY(%s::uuid[])", (all_ctrl_uuids,))
    print(f"  [OK] Удалено {cur.rowcount} параметров")

    print("[..] Удаление папок устройств и источников данных...")
    cur.execute("DELETE FROM admin.project_tree WHERE ref_uuid = ANY(%s::uuid[]) AND ref_type_id IN (2, 4)",
                (all_dev_uuids + all_ctrl_uuids,))
    print(f"  [OK] Удалено {cur.rowcount} нод")

    print("[..] Удаление контроллеров...")
    cur.execute("DELETE FROM admin.controller WHERE uuid = ANY(%s::uuid[])", (all_ctrl_uuids,))
    print(f"  [OK] Удалено {cur.rowcount} контроллеров")

    conn.commit()
    cur.close()
    conn.close()
    print("\n=== Тестовая среда удалена ===")


# ── Helpers ───────────────────────────────────────────────────────────────────
def _tree_exists(cur, ref_uuid: str, ref_type_id: int) -> bool:
    cur.execute("SELECT 1 FROM admin.project_tree WHERE ref_uuid = %s::uuid AND ref_type_id = %s LIMIT 1",
                (ref_uuid, ref_type_id))
    return cur.fetchone() is not None


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Test environment for Power Quality Microservice')
    sub = parser.add_subparsers(dest='cmd', required=True)

    p_create = sub.add_parser('create', help='Create test devices and generate data')
    p_create.add_argument('--days',     type=int, default=30,
                          help='How many days of historical data (default: 30)')
    p_create.add_argument('--interval', type=int, default=15,
                          help='Data interval in minutes (default: 15)')
    p_create.add_argument('--project',  type=str, default=None,
                          help='GAUSS project name (if omitted — auto-select or prompt)')

    p_delete = sub.add_parser('delete', help='Remove all test devices and data')
    p_delete.add_argument('--project',  type=str, default=None,
                          help='GAUSS project name (if omitted — auto-select or prompt)')

    args = parser.parse_args()

    if args.cmd == 'create':
        create(days=args.days, interval_min=args.interval, project_name=args.project)
    elif args.cmd == 'delete':
        delete(project_name=args.project)
