"""
Реестр типов устройств и карта регистров Modbus.

Логические имена параметров → адреса регистров (Channel 1 / base).
Для многоканальных устройств (MAP12E) адрес = base + (ch-1) * CHANNEL_OFFSET.
"""

import re
from dataclasses import dataclass, field

CHANNEL_OFFSET_MAP12E = 4096  # 0x1000 per channel


@dataclass
class DeviceType:
    code: str               # 'map3e', 'map12e', 'optimer', 'optimat'
    label: str              # Human-readable name
    channels: int           # number of independent measurement channels
    channel_offset: int     # address offset per channel (0 if single-channel)
    params: dict            # logical_name -> register_dec (channel 1 base)
    voltage_nominal: int    # 380 or 220 (default, can be overridden per channel)


# ─── OptiSmart MAP3E ─────────────────────────────────────────────────────────
_MAP3E_PARAMS = {
    'voltage_l1':      5136,
    'voltage_l2':      5138,
    'voltage_l3':      5140,
    'voltage_l1l2':    5148,
    'voltage_l2l3':    5149,
    'voltage_l3l1':    5150,
    'voltage_peak_l1': 6160,
    'voltage_peak_l2': 6162,
    'voltage_peak_l3': 6164,
    'frequency':       4344,
    'phase_angle_l1':  4345,
    'phase_angle_l2':  4346,
    'phase_angle_l3':  4347,
    'current_l1':      5142,
    'current_l2':      5144,
    'current_l3':      5146,
    'current_peak_l1': 6168,
    'current_peak_l2': 6170,
    'current_peak_l3': 6172,
    'p_l1':            4866,
    'q_l1':            4874,
    's_l1':            4882,
    'pf_l1':           4285,
    'p_l2':            4868,
    'q_l2':            4876,
    's_l2':            4884,
    'pf_l2':           4286,
    'p_l3':            4870,
    'q_l3':            4878,
    's_l3':            4886,
    'pf_l3':           4287,
    'p_total':         4864,
    'q_total':         4872,
    's_total':         4880,
    'pf_total':        4284,
    # Energy — MAP3E uses big-endian at 0x1Axx
    'energy_ap_l1':    6660,
    'energy_an_l1':    6676,
    'energy_rp_l1':    6692,
    'energy_rn_l1':    6708,
    'energy_ap_l2':    6664,
    'energy_an_l2':    6680,
    'energy_rp_l2':    6696,
    'energy_rn_l2':    6712,
    'energy_ap_l3':    6668,
    'energy_an_l3':    6684,
    'energy_rp_l3':    6700,
    'energy_rn_l3':    6716,
    'energy_ap_total': 6656,
    'energy_an_total': 6672,
    'energy_rp_total': 6688,
    'energy_rn_total': 6704,
}

# ─── OptiSmart MAP12E — same params but energy at 0x12xx ─────────────────────
_MAP12E_PARAMS = {**_MAP3E_PARAMS,
    'energy_ap_l1':    4612,
    'energy_an_l1':    4628,
    'energy_rp_l1':    4644,
    'energy_rn_l1':    4660,
    'energy_ap_l2':    4616,
    'energy_an_l2':    4632,
    'energy_rp_l2':    4648,
    'energy_rn_l2':    4664,
    'energy_ap_l3':    4620,
    'energy_an_l3':    4636,
    'energy_rp_l3':    4652,
    'energy_rn_l3':    4668,
    'energy_ap_total': 4608,
    'energy_an_total': 4624,
    'energy_rp_total': 4640,
    'energy_rn_total': 4656,
}

# ─── OptiMer M500 ─────────────────────────────────────────────────────────────
# Key params from Table 14-5 primary analogue values (0x41xx, float)
_OPTIMER_PARAMS = {
    'frequency':       16652,  # 0x410C
    'current_l1':      16654,  # 0x410E — фаза A
    'current_l2':      16656,  # 0x4110 — фаза B
    'current_l3':      16660,  # 0x4114 — фаза C
    'voltage_l1':      16662,  # 0x4116 — фаза A
    'voltage_l2':      16664,  # 0x4118 — фаза B
    'voltage_l3':      16666,  # 0x411A — фаза C
    'voltage_l1l2':    16668,  # 0x411C
    'voltage_l2l3':    16670,  # 0x411E
    'voltage_l3l1':    16672,  # 0x4120
    'p_total':         16682,  # 0x412A
    'q_total':         16684,  # 0x412C
    's_total':         16686,  # 0x412E
    'pf_total':        16688,  # 0x4130
    'p_l1':            16696,  # 0x4138
    'q_l1':            16698,  # 0x413A
    's_l1':            16700,  # 0x413C
    'p_l2':            16702,  # 0x413E
    'q_l2':            16704,  # 0x4140
    's_l2':            16706,  # 0x4142
    'p_l3':            16708,  # 0x4144
    'q_l3':            16710,  # 0x4146
    's_l3':            16712,  # 0x4148
    # Energy counters (0x08xx, float)
    'energy_ap_total': 2048,   # 0x0800
    'energy_an_total': 2052,   # 0x0804
    'energy_rp_total': 2056,   # 0x0808
    'energy_rn_total': 2060,   # 0x080C
}

# ─── OptiMat T ────────────────────────────────────────────────────────────────
# Verified against create_optimat_t_registers.py and OptiMat T.docx
_OPTIMAT_PARAMS = {
    # Токи (0x1A05+, UINT)
    'current_l1':      6661,   # 0x1A05 — Ток фазы A (I1)
    'current_l2':      6662,   # 0x1A06 — Ток фазы B (I2)
    'current_l3':      6663,   # 0x1A07 — Ток фазы C (I3)
    'current_neutral': 6664,   # 0x1A08 — Ток нейтрали (IN)
    'current_ground':  6666,   # 0x1A0A — Ток замыкания на землю (Ig)
    # Линейные напряжения (0x1A0D+, UINT)
    'voltage_l1l2':    6669,   # 0x1A0D — U12
    'voltage_l2l3':    6670,   # 0x1A0E — U23
    'voltage_l3l1':    6671,   # 0x1A0F — U31
    # Фазные напряжения (0x1A11+, UINT)
    'voltage_l1':      6673,   # 0x1A11 — U1N
    'voltage_l2':      6674,   # 0x1A12 — U2N
    'voltage_l3':      6675,   # 0x1A13 — U3N
    # Мощности (0x1A16+, INT)
    'p_l1':            6678,   # 0x1A16 — Активная мощность PA (кВт)
    'p_l2':            6679,   # 0x1A17 — PB
    'p_l3':            6680,   # 0x1A18 — PC
    'p_total':         6681,   # 0x1A19 — P суммарная
    'q_total':         6685,   # 0x1A1D — Q суммарная (квар)
    's_total':         6689,   # 0x1A21 — S суммарная (кВА)
    'pf_total':        6693,   # 0x1A25 — cos φ суммарный (×0.001)
    # Частота (0x1A28, UINT, ×0.01 Гц)
    'frequency':       6696,   # 0x1A28
    # Энергия суммарная (0x1A2C+, INT64, 4 регистра)
    'energy_ap_total': 6700,   # 0x1A2C — Активная кВт·ч
    'energy_rp_total': 6704,   # 0x1A30 — Реактивная квар·ч
    # Статус
    'status_work':     6656,   # 0x1A00 — Рабочий статус 1
    'status_alarm':    6658,   # 0x1A02 — Причина аварии (bitmap)
    # THD (0x1C1E+, UINT, ×0.01% → с gain=0.01 хранится как %)
    'thd_current_l1':  7198,   # 0x1C1E — КГI тока L1
    'thd_current_l2':  7199,   # 0x1C1F — КГI тока L2
    'thd_current_l3':  7200,   # 0x1C20 — КГI тока L3
    'thd_voltage_l1':  7207,   # 0x1C27 — КГU напряжения U1N
    'thd_voltage_l2':  7208,   # 0x1C28 — КГU напряжения U2N
    'thd_voltage_l3':  7209,   # 0x1C29 — КГU напряжения U3N
}


# ─── Registry ─────────────────────────────────────────────────────────────────
DEVICES: dict[str, DeviceType] = {
    'map3e': DeviceType(
        code='map3e',
        label='OptiSmart MAP3E',
        channels=1,
        channel_offset=0,
        params=_MAP3E_PARAMS,
        voltage_nominal=380,
    ),
    'map12e': DeviceType(
        code='map12e',
        label='OptiSmart MAP12E',
        channels=4,
        channel_offset=4096,
        params=_MAP12E_PARAMS,
        voltage_nominal=380,
    ),
    'optimer': DeviceType(
        code='optimer',
        label='OptiMer M500',
        channels=1,
        channel_offset=0,
        params=_OPTIMER_PARAMS,
        voltage_nominal=380,
    ),
    'optimat': DeviceType(
        code='optimat',
        label='OptiMat T',
        channels=1,
        channel_offset=0,
        params=_OPTIMAT_PARAMS,
        voltage_nominal=380,
    ),
}

# Patterns to detect device type from folder name
_PATTERNS = [
    (re.compile(r'OptiSmart\s+MAP12E', re.I), 'map12e'),
    (re.compile(r'OptiSmart\s+MAP3E',  re.I), 'map3e'),
    (re.compile(r'OptiMer\s+M500',     re.I), 'optimer'),
    (re.compile(r'OptiMat\s+T',        re.I), 'optimat'),
]


def detect_device_type(folder_name: str) -> str | None:
    """Returns device type code from folder name, or None if unknown."""
    for pattern, code in _PATTERNS:
        if pattern.search(folder_name):
            return code
    return None


def get_device(folder_name: str) -> DeviceType | None:
    code = detect_device_type(folder_name)
    return DEVICES.get(code) if code else None
