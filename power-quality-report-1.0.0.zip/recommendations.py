"""
Движок рекомендаций по оборудованию.
Вход: ChannelResult + DeviceReport (из report_engine) → список Recommendation.
"""

import json
import math
import os
from dataclasses import dataclass, field
from typing import Optional

CATALOG_PATH = os.path.join(os.path.dirname(__file__), "equipment_catalog.json")


@dataclass
class Recommendation:
    priority: int          # 1=критично, 2=важно, 3=желательно
    category: str
    problem: str
    solution: str
    model: Optional[str] = None
    price_rub: Optional[int] = None
    vendor: Optional[str] = None
    url: Optional[str] = None   # прямая ссылка на товар в каталоге КЭАЗ
    specs: dict = field(default_factory=dict)


def load_catalog() -> dict:
    try:
        with open(CATALOG_PATH, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}


def _find_ukrm(catalog: list, q_needed: float) -> Optional[dict]:
    candidates = [u for u in catalog if u.get("q_kvar", 0) >= q_needed]
    return min(candidates, key=lambda u: u["q_kvar"]) if candidates else None


def _find_stabilizer(catalog: list, s_needed: float) -> Optional[dict]:
    candidates = [s for s in catalog if s.get("s_kva", 0) >= s_needed]
    return min(candidates, key=lambda s: s["s_kva"]) if candidates else None


def _find_dgu(catalog: list, p_needed: float) -> Optional[dict]:
    candidates = [d for d in catalog if d.get("p_kw", 0) >= p_needed]
    return min(candidates, key=lambda d: d["p_kw"]) if candidates else None


def build_recommendations(report) -> list[Recommendation]:
    """
    report: DeviceReport из report_engine.py
    Берёт данные из первого канала для расчётов мощности/PF.
    """
    try:
        catalog = load_catalog()
    except Exception:
        return []

    recs = []
    ch = report.channels[0] if report.channels else None
    if ch is None:
        return []

    pf    = ch.power_factor
    p_met = ch.power.get('p_total')
    s_met = ch.power.get('s_total')
    k2u   = ch.asymmetry.get('voltage')
    ki    = ch.asymmetry.get('current')

    # MAP3E/MAP12E записывают мощность в Вт → делим на 1000
    # OptiMer/OptiMat — тоже в Вт по нашей схеме
    p_kw  = (p_met.mean / 1000) if p_met and p_met.status != 'no_data' else 0
    p_max = (p_met.max  / 1000) if p_met and p_met.status != 'no_data' else 0
    s_max = (s_met.max  / 1000) if s_met and s_met.status != 'no_data' else 0

    keaz_url      = catalog.get("vendor", {}).get("catalog_url", "https://keaz.ru/catalog#?target")
    helpdesk_url  = catalog.get("vendor", {}).get("helpdesk_url", "https://keaz.ru/helpdesk/tasks/add")

    # ── 1. УКРМ — компенсация реактивной мощности ─────────────────────────
    if pf and pf.status != 'no_data' and pf.mean < 0.92 and p_kw > 0:
        pf_cur = max(pf.mean, 0.1)
        tg_cur = math.tan(math.acos(pf_cur))
        tg_tgt = math.tan(math.acos(0.95))
        q_need = max(round(p_kw * (tg_cur - tg_tgt), 1), 1.0)
        recs.append(Recommendation(
            priority=1,
            category="Компенсация реактивной мощности",
            problem=(f"cos φ = {pf.mean:.3f} — ниже нормы 0.92. "
                     "Штрафы за реактивную мощность, перегрузка сети."),
            solution=f"Установить УКРМ мощностью ≥{q_need:.0f} кВАр (конденсаторная установка 0,4 кВ)",
            vendor="КЭАЗ",
            url=helpdesk_url,
            specs={"Q расч., кВАр": q_need},
        ))

    # ── 2. Несимметрия токов — активный фильтр КЭАЗ ───────────────────────
    if ki and ki.status != 'no_data' and ki.mean > 15:
        sev = "критическая" if ki.mean > 25 else "значительная"
        af = catalog["active_filter"][0] if catalog.get("active_filter") else None
        recs.append(Recommendation(
            priority=1 if ki.mean > 25 else 2,
            category="Несимметрия нагрузки",
            problem=(f"Несимметрия токов {sev}: среднее {ki.mean:.1f}%, макс {ki.max:.1f}%. "
                     "Перегрев нейтрали, дополнительные потери."),
            solution=("Перераспределить однофазные нагрузки по фазам. "
                      "При невозможности — установить активный фильтр симметрирования КЭАЗ."),
            model=af["model"] if af else None,
            vendor=af["vendor"] if af else None,
            url=af["url"] if af else None,
            specs={"Несимметрия ср., %": round(ki.mean, 1),
                   "Несимметрия макс., %": round(ki.max, 1)},
        ))

    # ── 3. Несимметрия / отклонение напряжения ────────────────────────────
    if k2u and k2u.status != 'no_data' and k2u.max > 2.0 and s_max > 0:
        recs.append(Recommendation(
            priority=2,
            category="Несимметрия напряжения",
            problem=(f"K2U до {k2u.max:.1f}% (норма ≤ 2%). "
                     "Перегрев электродвигателей, сокращение ресурса оборудования."),
            solution=f"Установить трёхфазный стабилизатор напряжения ≥{round(s_max*1.2):.0f} кВА",
            vendor="КЭАЗ",
            url=helpdesk_url,
            specs={"S нагрузки макс., кВА": round(s_max, 1)},
        ))

    # ── 4. Отклонение напряжения ───────────────────────────────────────────
    v_viols = [m for m in ch.voltage
               if 'Отклонение' in m.name
               and m.violations_pct and m.violations_pct > 1.0]
    if v_viols and s_max > 0:
        max_dev = max(m.max for m in v_viols)
        if not any(r.category == "Несимметрия напряжения" for r in recs):
            recs.append(Recommendation(
                priority=2,
                category="Отклонение напряжения",
                problem=(f"Напряжение отклоняется до {max_dev:.1f}% от номинала (норма ±5%). "
                         "Риск повреждения чувствительного оборудования."),
                solution=f"Установить стабилизатор напряжения ≥{round(s_max*1.2):.0f} кВА",
                vendor="КЭАЗ",
                url=helpdesk_url,
                specs={"S нагрузки макс., кВА": round(s_max, 1)},
            ))

    # ── 5. Резервное питание — АВР КЭАЗ + ДГУ ────────────────────────────
    if report.outages and p_max > 0:
        avr_list = catalog.get("avr", [])
        avr = avr_list[0] if avr_list else None
        recs.append(Recommendation(
            priority=2,
            category="Резервное электроснабжение",
            problem=(f"Зафиксировано {len(report.outages)} факт(а/ов) обесточивания. "
                     "Отсутствие резервного питания ведёт к потерям производства."),
            solution=f"Установить ДГУ ≥{round(p_max*0.7):.0f} кВт + блок АВР КЭАЗ",
            model=avr["model"] if avr else None,
            vendor=avr["vendor"] if avr else None,
            url=avr["url"] if avr else None,
            specs={"P пиковая нагрузки, кВт": round(p_max, 1)},
        ))

    # ── 6. Интервал архивации ──────────────────────────────────────────────
    if report.interval_hours > 1.0:
        recs.append(Recommendation(
            priority=3,
            category="Настройка архивации",
            problem=(f"Интервал записи {report.interval_hours:.1f} ч — слишком редко "
                     "для фиксации кратковременных событий (провалы, перенапряжения)."),
            solution=("Уменьшить интервал архивации до 10–30 секунд в настройках контроллера. "
                      "Это позволит фиксировать быстрые нарушения ГОСТ."),
            specs={"Текущий интервал, ч": report.interval_hours, "Рекомендуемый, с": 30},
        ))

    recs.sort(key=lambda r: r.priority)
    return recs
