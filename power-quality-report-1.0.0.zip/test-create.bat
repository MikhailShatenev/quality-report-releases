@echo off
echo ============================================
echo  Создание тестовых устройств и данных
echo ============================================
echo.
echo Запуск займёт 1-3 минуты...
echo.
docker exec pq_report_app python /app/setup_test_env.py create --days 30 --interval 15
echo.
if %ERRORLEVEL% EQU 0 (
    echo [OK] Тестовые данные созданы.
    echo      Откройте GAUSS Client и выберите устройство для отчёта.
) else (
    echo [ERR] Ошибка. Убедитесь что микросервис запущен: docker compose ps
)
echo.
pause
