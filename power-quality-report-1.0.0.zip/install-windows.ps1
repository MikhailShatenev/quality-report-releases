﻿# Установка Power Quality Report на Windows
# Запуск: powershell -ExecutionPolicy Bypass -File install-windows.ps1

$ErrorActionPreference = "Stop"

function Ok   { param($msg) Write-Host "[OK]  $msg" -ForegroundColor Green }
function Warn { param($msg) Write-Host "[!!]  $msg" -ForegroundColor Yellow }
function Fail { param($msg) Write-Host "[ERR] $msg" -ForegroundColor Red; exit 1 }

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

Write-Host "=== Установка Power Quality Report ===" -ForegroundColor Cyan
Write-Host ""

# ── 0. Свободное место на диске ───────────────────────────────────────────────
$freeGB = [math]::Round((Get-PSDrive C).Free / 1GB, 1)
if ($freeGB -lt 10) {
    Fail "Недостаточно места на диске C: (свободно ${freeGB} ГБ, нужно минимум 10 ГБ). Освободите место и запустите установку повторно."
}
Ok "Свободно на C: ${freeGB} ГБ"

# ── 1. Docker Desktop ─────────────────────────────────────────────────────────
try {
    $v = docker --version 2>&1
    Ok "Docker: $v"
} catch {
    Fail "Docker Desktop не установлен. Скачайте с https://www.docker.com/products/docker-desktop/"
}

try {
    docker compose version | Out-Null
    Ok "Docker Compose доступен"
} catch {
    Fail "Docker Compose не найден. Обновите Docker Desktop."
}


# ── 2. Уже запущен? ───────────────────────────────────────────────────────────
Write-Host ""
Write-Host "Проверка запущенных контейнеров..."
$alreadyRunning = docker compose ps --status running 2>$null | Select-String "pq_report"
if ($alreadyRunning) {
    Ok "Контейнеры уже запущены — пропускаем сборку."
} else {
    # ── 3. PostgreSQL ──────────────────────────────────────────────────────────
    $PG_PORT = if ($env:PG_PORT) { $env:PG_PORT } else { "5432" }
    Write-Host ""
    Write-Host "Проверка PostgreSQL на порту $PG_PORT..."
    $pgListening = Get-NetTCPConnection -LocalPort $PG_PORT -State Listen -ErrorAction SilentlyContinue
    if (-not $pgListening) {
        Fail "PostgreSQL не запущен на порту $PG_PORT. Установите GAUSS перед установкой микросервиса."
    }
    Ok "PostgreSQL доступен на порту $PG_PORT"

    # ── 4. Порт 8000 ──────────────────────────────────────────────────────────
    Write-Host ""
    Write-Host "Проверка порта 8000..."
    $port8000 = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
    if ($port8000) {
        $proc = Get-Process -Id $port8000.OwningProcess -ErrorAction SilentlyContinue
        $procName = if ($proc) { $proc.Name } else { "неизвестен" }
        Fail "Порт 8000 занят процессом '$procName' (PID $($port8000.OwningProcess)). Освободите порт и запустите установку повторно."
    }
    Ok "Порт 8000 свободен"

    # ── 5. Сборка и запуск ────────────────────────────────────────────────────
    Write-Host ""
    Write-Host "Сборка и запуск контейнеров..."
    docker rmi pq-report-app 2>$null | Out-Null
    docker compose build --no-cache
    if ($LASTEXITCODE -ne 0) { Fail "Ошибка сборки образа. Проверьте логи выше." }
    docker compose up -d
    if ($LASTEXITCODE -ne 0) { Fail "Ошибка запуска контейнеров." }
}

# ── 6. Автозапуск ─────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "Настройка автозапуска..."
$taskName = "PowerQualityReport-Autostart"
$psScript  = $MyInvocation.MyCommand.Path
Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction SilentlyContinue
$action    = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$psScript`""
$trigger   = New-ScheduledTaskTrigger -AtStartup
$settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
try {
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger `
        -Settings $settings -Principal $principal -Force | Out-Null
    Ok "Автозапуск настроен (Планировщик задач: '$taskName')"
} catch {
    Warn "Автозапуск не настроен — запустите скрипт от имени администратора для настройки автозапуска."
}

# ── 7. Регистрация веб-страницы в GAUSS ──────────────────────────────────────
# Регистрация выполняется автоматически микросервисом при первом запуске
# через _ensure_gauss_page() в main.py (отдельный UUID на каждый проект GAUSS)
Write-Host ""
Ok "Веб-страница будет зарегистрирована автоматически при первом запуске сервиса"

# ── 8. Проверка ───────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "Проверка запуска (ожидание 10 сек)..."
Start-Sleep -Seconds 10
$running = docker compose ps | Select-String "Up"
if (-not $running) {
    Fail "Контейнеры не запустились. Проверьте: docker compose logs"
}
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8000/" -TimeoutSec 5 -UseBasicParsing
    if ($response.StatusCode -eq 200) {
        Ok "Микросервис отвечает на http://localhost:8000/"
    } else {
        Warn "HTTP ответ: $($response.StatusCode)"
    }
} catch {
    Warn "Нет ответа от сервиса. Проверьте: docker compose logs pq_report_app"
}

Write-Host ""
Write-Host "=== Установка завершена ===" -ForegroundColor Cyan
Write-Host "Сервис: http://localhost:8000/"
Write-Host "Логи:   docker compose logs -f"
Write-Host "Стоп:   docker compose down"
Write-Host ""
Write-Host "Для первого открытия в GAUSS Client:" -ForegroundColor Yellow
Write-Host "  1. Откройте любую другую вкладку в левой панели"
Write-Host "  2. Нажмите на 'Power Quality Report' в дереве проекта"

