"""
FastAPI микросервис анализа качества электроэнергии v2.

Endpoints:
  GET  /health
  GET  /devices                   → JSON список устройств с типами
  GET  /channel-config/{folder_id}  → JSON текущая конфигурация каналов
  POST /channel-config/{folder_id}  → сохранить конфигурацию каналов
  GET  /                          → config.html (конфигуратор)
  GET  /report/html               → HTML-отчёт
  GET  /report/pdf                → PDF-отчёт
"""

import os
import uuid
import time
import queue
import threading
import json
import psycopg2
from datetime import datetime
from typing import Optional, List
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, Response, JSONResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from device_registry import detect_device_type, get_device, DEVICES
from param_resolver import resolve_params
from channel_config import (
    get_channel_config, set_channel_config,
    get_all_channel_types, get_voltage_for_channel,
    set_load_names, get_all_load_names,
    CHANNEL_TYPE_LABELS,
)
from report_engine import run_device_report, REPORT_DB

# ─── Report cache (для SSE-прогресса) ────────────────────────────────────────
_report_cache: dict[str, tuple[str, float]] = {}  # token -> (html, timestamp)

def _cache_cleanup():
    now = time.time()
    for k in [k for k, (_, ts) in _report_cache.items() if now - ts > 120]:
        _report_cache.pop(k, None)

# ─── DB configs ───────────────────────────────────────────────────────────────
AGS_DB = dict(
    host=os.getenv("PG_HOST", "localhost"),
    port=int(os.getenv("PG_PORT", "5432")),
    dbname="ags",
    user=os.getenv("PG_USER", "postgres"),
    password=os.getenv("PG_PASS", "postgres"),
)
# REPORT_DB already defined in report_engine; keep local reference for queries here
_REPORT_DB = dict(
    host=os.getenv("PG_HOST", "localhost"),
    port=int(os.getenv("PG_PORT", "5432")),
    dbname="report",
    user=os.getenv("PG_USER", "postgres"),
    password=os.getenv("PG_PASS", "postgres"),
)

templates = Jinja2Templates(directory="templates")

app = FastAPI(
    title="Power Quality Microservice",
    description="Анализ качества электроэнергии по ГОСТ 32144-2013",
    version="2.0.0",
)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])

# ─── GAUSS auto-registration ───────────────────────────────────────────────────

_PAGE_NAME = 'Power Quality Report'
_PAGE_URL  = 'http://127.0.0.1:8000/'

# Namespace UUID для генерации детерминированных page UUID по project_uuid (uuid5)
_PAGE_NS   = uuid.UUID('ee000010-feed-0000-0000-000000000000')

def _page_uuid_for_project(project_uuid: str) -> str:
    """Детерминированный UUID страницы для конкретного проекта GAUSS."""
    return str(uuid.uuid5(_PAGE_NS, str(project_uuid)))


def _ensure_gauss_page():
    """
    При старте проверяет все проекты в GAUSS и добавляет Web-страницу
    микросервиса туда, где её ещё нет.

    Каждый проект получает ОТДЕЛЬНУЮ запись admin.page с уникальным UUID
    и URL вида http://127.0.0.1:8000/?project=<project_uuid>.
    Это позволяет микросервису знать, из какого проекта открыта страница,
    и показывать только устройства этого проекта.

    Не падает при ошибках — только пишет в лог.
    """
    try:
        conn = _ags_conn()
        cur  = conn.cursor()

        # Получить все проекты (каждый проект имеет корневой узел ref_type_id=5)
        cur.execute("""
            SELECT DISTINCT project_uuid FROM admin.project_tree
            WHERE project_uuid IS NOT NULL AND ref_type_id = 5
        """)
        project_uuids = [r[0] for r in cur.fetchall()]

        added = 0
        for proj_uuid in project_uuids:
            proj_uuid_str = str(proj_uuid)
            page_uuid     = _page_uuid_for_project(proj_uuid_str)
            page_body     = f'<Web url="http://127.0.0.1:8000/?project={proj_uuid_str}" />'

            # 1. Создать/обновить запись admin.page для этого проекта
            # body ОБЯЗАН быть XML-строкой <Web url="..." /> — plain URL крашит GAUSS Client
            cur.execute("""
                INSERT INTO admin.page (uuid, type_id, body)
                VALUES (%s::uuid, 4, %s)
                ON CONFLICT (uuid) DO UPDATE SET body = EXCLUDED.body
            """, (page_uuid, page_body))

            # 2. Найти корневой узел проекта
            cur.execute("""
                SELECT id FROM admin.project_tree
                WHERE project_uuid = %s::uuid AND ref_type_id = 5
                LIMIT 1
            """, (proj_uuid,))
            root = cur.fetchone()
            if not root:
                continue

            # 3. Удалить старую запись без ?project= (миграция со старой схемы)
            cur.execute("""
                DELETE FROM admin.project_tree
                WHERE project_uuid = %s::uuid
                  AND ref_uuid NOT IN (SELECT uuid FROM admin.page WHERE body LIKE %s)
                  AND ref_type_id = 6
                  AND name = %s
            """, (proj_uuid, f'%?project={proj_uuid_str}%', _PAGE_NAME))

            # 4. Добавить страницу если ещё нет в этом проекте
            cur.execute("""
                SELECT 1 FROM admin.project_tree
                WHERE ref_uuid = %s::uuid AND project_uuid = %s::uuid
            """, (page_uuid, proj_uuid))
            if not cur.fetchone():
                cur.execute("""
                    INSERT INTO admin.project_tree
                        (name, parent_id, project_uuid, ref_type_id, ref_uuid, "order")
                    VALUES (%s, %s, %s::uuid, 6, %s::uuid, 999)
                """, (_PAGE_NAME, root[0], proj_uuid, page_uuid))
                added += 1

        conn.commit()
        cur.close()
        conn.close()

        if added:
            print(f"[auto-register] Добавлена страница в {added} проект(ов) GAUSS")
    except Exception as e:
        print(f"[auto-register] Предупреждение: {e}")


@app.on_event("startup")
async def startup():
    threading.Thread(target=_ensure_gauss_page, daemon=True).start()


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _ags_conn():
    return psycopg2.connect(**AGS_DB)


def _report_conn():
    return psycopg2.connect(**_REPORT_DB)


def _get_known_devices(project_uuid: str = None) -> list[dict]:
    """
    Returns device folders from Структура section in ags DB.
    If project_uuid is given — only devices of that project.
    Detects device type from folder name.
    """
    try:
        conn = _ags_conn()
        cur = conn.cursor()
        if project_uuid:
            cur.execute("""
                SELECT
                    folder.id,
                    folder.name,
                    folder."order",
                    folder.ref_uuid::text
                FROM admin.project_tree folder
                WHERE folder.ref_type_id = 2
                  AND folder.parent_id IN (
                      SELECT id FROM admin.project_tree
                      WHERE ref_type_id = 17
                        AND project_uuid = %s::uuid
                  )
                ORDER BY folder."order", folder.name
            """, (project_uuid,))
        else:
            cur.execute("""
                SELECT
                    folder.id,
                    folder.name,
                    folder."order",
                    folder.ref_uuid::text
                FROM admin.project_tree folder
                WHERE folder.ref_type_id = 2
                  AND folder.parent_id IN (
                      SELECT id FROM admin.project_tree WHERE ref_type_id = 17
                  )
                ORDER BY folder."order", folder.name
            """)
        rows = cur.fetchall()
        cur.close()
        conn.close()
    except Exception as e:
        return []

    result = []
    for (folder_id, name, order, folder_uuid) in rows:
        dt_code = detect_device_type(name or "")
        dt = DEVICES.get(dt_code) if dt_code else None
        result.append({
            "folder_id":         folder_id,
            "folder_uuid":       folder_uuid,
            "name":              name or f"Устройство {folder_id}",
            "device_type":       dt_code,
            "device_type_label": dt.label if dt else "Неизвестный тип",
            "channels":          dt.channels if dt else 1,
            "is_known_type":     dt is not None,
        })
    return result


def _get_device_by_folder(folder_id: int) -> dict | None:
    devices = _get_known_devices()
    return next((d for d in devices if d["folder_id"] == folder_id), None)


def _insufficient_response(device_name: str, issues: list[str]) -> HTMLResponse:
    items = "".join(
        f'<li style="margin:4px 0;color:#f87171">{i}</li>' for i in issues
    )
    html = f"""<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8">
<style>
  *{{margin:0;padding:0;box-sizing:border-box;}}
  body{{font-family:Inter,system-ui,sans-serif;background:#080a10;color:#e8ecf0;
       display:flex;align-items:center;justify-content:center;min-height:100vh;}}
  .box{{max-width:520px;padding:40px 36px;text-align:center;}}
  .icon{{font-size:36px;margin-bottom:16px;opacity:.45;}}
  .title{{font-size:15px;font-weight:600;color:#fbbf24;margin-bottom:6px;}}
  .device{{font-size:12px;color:rgba(255,255,255,.35);margin-bottom:20px;}}
  .wrap{{background:rgba(248,113,113,.06);border:1px solid rgba(248,113,113,.15);
         border-radius:10px;padding:14px 18px;text-align:left;}}
  .label{{font-size:11px;font-weight:600;color:rgba(255,255,255,.25);
          text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px;}}
  ul{{list-style:none;padding:0;font-size:12px;}}
</style></head><body>
<div class="box">
  <div class="icon">&#9888;</div>
  <div class="title">Невозможно построить отчёт</div>
  <div class="device">{device_name}</div>
  <div class="wrap">
    <div class="label">Проблемы</div>
    <ul>{items}</ul>
  </div>
</div></body></html>"""
    return HTMLResponse(content=html)


def _no_data_page(device_names: str, period_str: str, theme: str) -> str:
    bg = "#0A0B12" if theme == "dark" else "#F0FAFA"
    surface = "#13141D" if theme == "dark" else "#FFFFFF"
    text1 = "#FFFFFF" if theme == "dark" else "#0D1117"
    text3 = "rgba(200,205,216,.5)" if theme == "dark" else "#6B7280"
    border = "rgba(255,255,255,.08)" if theme == "dark" else "#C4C9D4"
    period_line = f"<div style='font-size:13px;color:{text3};margin-top:6px;'>Период: <b style=\"color:{text1}\">{period_str}</b></div>" if period_str else ""
    return f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<style>*{{margin:0;padding:0;box-sizing:border-box;}}
body{{font-family:Inter,system-ui,sans-serif;background:{bg};color:{text1};
  height:100vh;display:flex;align-items:center;justify-content:center;}}
.box{{background:{surface};border:1px solid {border};border-radius:16px;
  padding:40px 48px;max-width:480px;text-align:center;}}
.icon{{font-size:48px;margin-bottom:20px;}}
.title{{font-size:18px;font-weight:700;margin-bottom:10px;}}
.msg{{font-size:13px;color:{text3};line-height:1.6;}}
</style></head><body>
<div class="box">
  <div class="icon">📭</div>
  <div class="title">Нет данных за указанный период</div>
  <div class="msg">
    Устройство: <b style="color:{text1}">{device_names}</b>
    {period_line}
    <br><br>Убедитесь, что тренды за этот период загружены в ГАУС,<br>
    или выберите другой диапазон дат.
  </div>
</div>
</body></html>"""


MAX_PERIOD_DAYS   = 365   # максимальный период отчёта — 1 год
MAX_TOTAL_CHANNELS = 28  # макс. каналов суммарно (= 7 MAP12E × 4 или 28 однофазных)


def _build_report_html(folder_ids: list[int],
                       date_from: datetime | None,
                       date_to: datetime | None,
                       theme: str | None = None,
                       auto_print: bool = False,
                       on_progress=None) -> str:
    """
    Core logic: resolve params, run analysis, render HTML.
    Raises HTTPException on validation errors.
    """
    # Validate: period ≤ 1 year
    if date_from and date_to:
        delta = (date_to - date_from).days
        if delta < 0:
            raise HTTPException(400, "Дата начала позже даты окончания")
        if delta > MAX_PERIOD_DAYS:
            raise HTTPException(400,
                f"Период отчёта не может превышать {MAX_PERIOD_DAYS} дней (1 год). "
                f"Выбрано: {delta} дней.")

    # Load device info for each folder
    devices_info = [_get_device_by_folder(fid) for fid in folder_ids]

    # Validate: all devices must be known type
    for info, fid in zip(devices_info, folder_ids):
        if info is None:
            raise HTTPException(400, f"Папка {fid} не найдена")
        if not info["is_known_type"]:
            raise HTTPException(400,
                f"Устройство «{info['name']}» неизвестного типа — "
                "отчёт поддерживается только для OptiMat T, OptiMer M500, "
                "OptiSmart MAP3E и OptiSmart MAP12E")

    # Validate: total channels ≤ 28
    total_channels = sum(
        DEVICES[d["device_type"]].channels for d in devices_info
    )
    if total_channels > MAX_TOTAL_CHANNELS:
        raise HTTPException(400,
            f"Слишком много каналов для группового отчёта: {total_channels}. "
            f"Максимум — {MAX_TOTAL_CHANNELS} каналов "
            f"(не более 7 устройств MAP12E или 28 однофазных).")

    # Ограничение на одинаковый тип снято — групповой отчёт разрешён для любых типов.
    # Сравнительная таблица содержит только общие метрики (напряжение, cos φ, частота, ГОСТ).
    # THD показывается только в индивидуальной секции OptiMat T.

    reports = []
    n_devs = len(folder_ids)
    for dev_idx, (info, fid) in enumerate(zip(devices_info, folder_ids)):
        dt = DEVICES[info["device_type"]]
        n_channels = dt.channels

        # Scale progress to this device's share of 0–80%
        dev_base = dev_idx * 80 // n_devs
        dev_step = 80 // n_devs
        def _dev_progress(pct, msg='', _base=dev_base, _step=dev_step):
            if on_progress:
                on_progress(_base + pct * _step // 100, msg)

        # Resolve params per channel (use folder_uuid for portable lookup)
        fkey = info["folder_uuid"]
        resolved_per_channel = {}
        channel_voltages = {}
        for ch in range(1, n_channels + 1):
            resolved_per_channel[ch] = resolve_params(fkey, dt, ch)
            channel_voltages[ch] = get_voltage_for_channel(fkey, ch)

        channel_load_names = get_all_load_names(fkey, n_channels)

        report = run_device_report(
            device_name=info["name"],
            device_type=dt,
            folder_id=fid,
            resolved_per_channel=resolved_per_channel,
            channel_voltages=channel_voltages,
            channel_load_names=channel_load_names,
            date_from=date_from,
            date_to=date_to,
            on_progress=_dev_progress,
        )
        reports.append(report)

    # Проверка: есть ли хоть какие-то данные за период
    all_no_data = all(
        all(not ch.has_data for ch in r.channels)
        for r in reports
    )
    if all_no_data:
        period_str = ""
        if date_from and date_to:
            period_str = f"{date_from.strftime('%d.%m.%Y')} — {date_to.strftime('%d.%m.%Y')}"
        elif date_from:
            period_str = f"с {date_from.strftime('%d.%m.%Y')}"
        elif date_to:
            period_str = f"по {date_to.strftime('%d.%m.%Y')}"
        device_names = ", ".join(r.device_name for r in reports)
        return _no_data_page(device_names, period_str, theme or 'dark')

    # Render template
    import jinja2
    env = jinja2.Environment(
        loader=jinja2.FileSystemLoader("templates"),
        autoescape=True,
    )
    tmpl = env.get_template("report_gost.html")
    is_group = len(reports) > 1
    return tmpl.render(
        reports=reports,
        is_group=is_group,
        generated_at=datetime.now().strftime("%d.%m.%Y %H:%M"),
        channel_type_labels=CHANNEL_TYPE_LABELS,
        theme=theme or 'dark',
        auto_print=auto_print,
        requested_date_from=date_from,
        requested_date_to=date_to,
    )


# ─── Endpoints ────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok", "version": "2.0.0"}


@app.get("/devices")
def devices(project: Optional[str] = Query(None)):
    """All device folders with device type detection. Optionally filtered by project_uuid."""
    return _get_known_devices(project_uuid=project)


@app.get("/controllers")
def controllers(project: Optional[str] = Query(None)):
    """Legacy alias for /devices (kept for config.html compatibility)."""
    return _get_known_devices(project_uuid=project)


@app.get("/channel-config/{folder_id}")
def get_channel_cfg(folder_id: int):
    info = _get_device_by_folder(folder_id)
    if not info:
        raise HTTPException(404, "Папка не найдена")
    dt = DEVICES.get(info["device_type"])
    n = dt.channels if dt else 1
    fkey = info["folder_uuid"]
    channel_types = get_all_channel_types(fkey, n)
    load_names    = get_all_load_names(fkey, n)
    return {
        "folder_id": folder_id,
        "device_type": info["device_type"],
        "channels": {
            str(ch): {
                "type": ctype,
                "label": CHANNEL_TYPE_LABELS.get(ctype, ctype),
                "voltage_nominal": 220 if ctype == "1phase_x3" else 380,
                "load_name": load_names.get(ch, ""),
            }
            for ch, ctype in channel_types.items()
        },
    }


class ChannelConfigPayload(BaseModel):
    channels:   dict[str, str]  = {}   # {"1": "3phase", "2": "1phase_x3", ...}
    load_names: dict[str, str]  = {}   # {"1": "Насосная ст. №1", "2": "Компрессор"}


@app.post("/channel-config/{folder_id}")
def save_channel_cfg(folder_id: int, payload: ChannelConfigPayload):
    info = _get_device_by_folder(folder_id)
    if not info:
        raise HTTPException(404, "Папка не найдена")
    fkey = info["folder_uuid"]
    if payload.channels:
        set_channel_config(fkey, info["device_type"], payload.channels)
    if payload.load_names is not None:
        set_load_names(fkey, payload.load_names)
    return {"status": "saved"}


@app.get("/", response_class=HTMLResponse)
def config_page(request: Request, project: Optional[str] = Query(None)):
    device_list = _get_known_devices(project_uuid=project)
    return templates.TemplateResponse("config.html", {
        "request": request,
        "devices": device_list,
        "channel_type_labels": CHANNEL_TYPE_LABELS,
        "project_uuid": project or "",
    })


@app.get("/report/html", response_class=HTMLResponse)
def report_html(
    device:     List[int]     = Query(default=[]),
    date_from:  Optional[str] = Query(None),
    date_to:    Optional[str] = Query(None),
    theme:      Optional[str] = Query(None),
    auto_print: int           = Query(0),
):
    if not device:
        raise HTTPException(400, "Укажите хотя бы одно устройство")
    df = datetime.fromisoformat(date_from) if date_from else None
    dt = datetime.fromisoformat(date_to)   if date_to   else None
    html = _build_report_html(device, df, dt, theme=theme, auto_print=bool(auto_print))
    return HTMLResponse(content=html)


@app.get("/report/pdf", response_class=HTMLResponse)
def report_pdf(
    device:    List[int]     = Query(default=[]),
    date_from: Optional[str] = Query(None),
    date_to:   Optional[str] = Query(None),
    theme:     Optional[str] = Query(None),
):
    if not device:
        raise HTTPException(400, "Укажите хотя бы одно устройство")
    df = datetime.fromisoformat(date_from) if date_from else None
    dt = datetime.fromisoformat(date_to)   if date_to   else None
    html = _build_report_html(device, df, dt, theme=theme, auto_print=True)
    return HTMLResponse(content=html)


@app.get("/report/cached/{token}", response_class=HTMLResponse)
def report_cached(token: str):
    """Возвращает ранее сгенерированный отчёт по одноразовому токену."""
    _cache_cleanup()
    entry = _report_cache.pop(token, None)
    if entry is None:
        raise HTTPException(404, "Отчёт не найден или истёк срок хранения")
    html, _ = entry
    return HTMLResponse(content=html)


@app.get("/report/progress")
def report_progress(
    device:    List[int]     = Query(default=[]),
    date_from: Optional[str] = Query(None),
    date_to:   Optional[str] = Query(None),
    theme:     Optional[str] = Query(None),
):
    """SSE-поток прогресса генерации отчёта. Финальное событие содержит token."""
    if not device:
        raise HTTPException(400, "Укажите хотя бы одно устройство")
    df = datetime.fromisoformat(date_from) if date_from else None
    dt = datetime.fromisoformat(date_to)   if date_to   else None

    prog_queue: queue.Queue = queue.Queue()
    result: dict = {}

    def on_progress(pct: int, msg: str = ""):
        prog_queue.put({"pct": pct, "msg": msg})

    def build():
        try:
            html = _build_report_html(device, df, dt, theme=theme, on_progress=on_progress)
            result["html"] = html
        except HTTPException as e:
            result["error"] = e.detail
        except Exception as e:
            result["error"] = str(e)
        finally:
            prog_queue.put(None)

    threading.Thread(target=build, daemon=True).start()

    def stream():
        while True:
            item = prog_queue.get()
            if item is None:
                break
            yield f"data: {json.dumps(item, ensure_ascii=False)}\n\n"
        if "html" in result:
            token = uuid.uuid4().hex[:12]
            _report_cache[token] = (result["html"], time.time())
            yield f"data: {json.dumps({'pct': 100, 'token': token}, ensure_ascii=False)}\n\n"
        else:
            yield f"data: {json.dumps({'pct': -1, 'error': result.get('error', 'Ошибка')}, ensure_ascii=False)}\n\n"

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )




