#!/bin/bash
echo "============================================"
echo " Создание тестовых устройств и данных"
echo "============================================"
echo ""
echo "Запуск займёт 1-3 минуты..."
echo ""
docker exec -it pq_report_app python /app/setup_test_env.py create --days 30 --interval 15
if [ $? -eq 0 ]; then
    echo ""
    echo "[OK] Тестовые данные созданы."
    echo "     Откройте GAUSS Client и выберите устройство для отчёта."
else
    echo ""
    echo "[ERR] Ошибка. Убедитесь что микросервис запущен: docker compose ps"
fi
