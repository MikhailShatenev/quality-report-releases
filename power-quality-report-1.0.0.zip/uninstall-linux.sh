#!/bin/bash
# Удаление Power Quality Report на Linux
# Запуск: sudo bash uninstall-linux.sh

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

ok()   { echo -e "${GREEN}[OK]${NC}  $1"; }
warn() { echo -e "${YELLOW}[!!]${NC}  $1"; }
info() { echo "[..]  $1"; }

echo "=== Удаление Power Quality Report ==="
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# ── 1. Остановка контейнеров и удаление образов ───────────────────────────────
info "Остановка контейнеров и удаление образов..."
docker compose down --rmi all 2>/dev/null || true
docker stop pq_report_nginx pq_report_app 2>/dev/null || true
docker rm   pq_report_nginx pq_report_app 2>/dev/null || true
docker rmi pq-report-app gauss-analytics-app microservice-app 2>/dev/null || true
ok "Контейнеры и образы удалены"

# ── 2. (резерв — уже сделано выше) ───────────────────────────────────────────

# ── 3. systemd-сервис ─────────────────────────────────────────────────────────
info "Удаление systemd-сервиса..."
if systemctl is-enabled power-quality-report.service &>/dev/null; then
    systemctl disable power-quality-report.service
    rm -f /etc/systemd/system/power-quality-report.service
    systemctl daemon-reload
    ok "systemd-сервис удалён"
else
    warn "systemd-сервис не найден — пропускаем"
fi

# ── 4. Очистка БД GAUSS ───────────────────────────────────────────────────────
info "Очистка записей в БД GAUSS..."
PG_HOST="${PG_HOST:-localhost}"
PG_PORT="${PG_PORT:-5432}"
PG_USER="${PG_USER:-postgres}"
PG_PASS="${PG_PASS:-postgres}"

if command -v psql &>/dev/null; then
    PGPASSWORD="$PG_PASS" psql -h "$PG_HOST" -p "$PG_PORT" -U "$PG_USER" -d ags -c "
        DELETE FROM admin.project_tree WHERE name = 'Power Quality Report';
        DELETE FROM admin.page WHERE body LIKE '%:8000%';
    " &>/dev/null
    ok "Записи микросервиса удалены из БД GAUSS"
else
    warn "psql не найден — удалите записи из БД GAUSS вручную"
fi

# ── 5. Удаление папки установки ───────────────────────────────────────────────
INSTALL_DIR="/opt/power-quality-report"
if [ -d "$INSTALL_DIR" ]; then
    info "Удаление $INSTALL_DIR..."
    rm -rf "$INSTALL_DIR"
    ok "Папка $INSTALL_DIR удалена"
else
    warn "Папка $INSTALL_DIR не найдена — пропускаем"
fi

echo ""
echo "=== Удаление завершено ==="
echo "Power Quality Report полностью удалён с этого компьютера."
