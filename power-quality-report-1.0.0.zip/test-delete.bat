@echo off
echo ============================================
echo  Удаление тестовых устройств и данных
echo ============================================
echo.
set /p CONFIRM=Удалить все тестовые данные? (y/N):
if /i not "%CONFIRM%"=="y" (
    echo Отменено.
    pause
    exit /b 0
)
echo.
docker exec pq_report_app python /app/setup_test_env.py delete
echo.
if %ERRORLEVEL% EQU 0 (
    echo [OK] Тестовые данные удалены.
) else (
    echo [ERR] Ошибка. Убедитесь что микросервис запущен: docker compose ps
)
echo.
pause
