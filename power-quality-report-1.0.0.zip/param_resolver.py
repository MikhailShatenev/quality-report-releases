"""
Resolver: находит UUID параметров в ags DB по папке и адресу регистра.

В address JSON каждого параметра хранится:
  [{"Name":"Register","Value":"DEC_ADDR"}, ...]

folder_key — UUID папки устройства (ref_uuid в project_tree, тип 2).
Используем UUID вместо integer id для портируемости между машинами.
"""

import json
import psycopg2
from typing import Optional

import os

# Connection to ags DB (config/admin database)
AGS_DB = dict(
    host     = os.environ.get('PG_HOST', 'localhost'),
    port     = int(os.environ.get('PG_PORT', 5432)),
    dbname   = os.environ.get('PG_DB',   'ags'),
    user     = os.environ.get('PG_USER', 'postgres'),
    password = os.environ.get('PG_PASS', 'postgres'),
)


def get_register_uuid_map(folder_uuid: str) -> dict[int, str]:
    """
    Returns {register_dec: parameter_uuid} for all parameters in the folder.
    folder_uuid — ref_uuid of the device folder in project_tree (type 2).
    """
    conn = psycopg2.connect(**AGS_DB)
    cur = conn.cursor()
    cur.execute("""
        SELECT p.uuid::text, p.address
        FROM admin.parameter p
        JOIN admin.project_tree pt ON pt.ref_uuid::uuid = p.uuid
        WHERE pt.parent_id = (
            SELECT id FROM admin.project_tree
            WHERE ref_uuid = %s::uuid AND ref_type_id = 2
            LIMIT 1
        ) AND pt.ref_type_id = 3
    """, (folder_uuid,))
    rows = cur.fetchall()
    cur.close()
    conn.close()

    result = {}
    for (puuid, address) in rows:
        try:
            addr_list = json.loads(address)
            reg_val = next(
                (item['Value'] for item in addr_list if item['Name'] == 'Register'),
                None
            )
            if reg_val is not None:
                result[int(reg_val)] = puuid
        except Exception:
            pass
    return result


def resolve_params(folder_uuid: str, device_type, channel: int = 1) -> dict[str, str]:
    """
    Returns {logical_name: parameter_uuid} for the given device folder and channel.

    folder_uuid: ref_uuid of the device folder in project_tree
    device_type: DeviceType instance from device_registry
    channel: 1-based channel number (for MAP12E: 1..4)
    """
    reg_to_uuid = get_register_uuid_map(folder_uuid)
    offset = (channel - 1) * device_type.channel_offset
    result = {}
    for logical_name, base_reg in device_type.params.items():
        actual_reg = base_reg + offset
        uuid = reg_to_uuid.get(actual_reg)
        if uuid:
            result[logical_name] = uuid
    return result


def check_trends_active(param_uuids: list[str]) -> dict[str, bool]:
    """
    Returns {param_uuid: has_active_trend} for the given parameter UUIDs.
    Checks admin.trend table.
    """
    if not param_uuids:
        return {}
    conn = psycopg2.connect(**AGS_DB)
    cur = conn.cursor()
    cur.execute("""
        SELECT parameter_uuid::text, is_active
        FROM admin.trend
        WHERE parameter_uuid::text = ANY(%s)
    """, (param_uuids,))
    rows = cur.fetchall()
    cur.close()
    conn.close()
    result = {puuid: False for puuid in param_uuids}
    for (puuid, is_active) in rows:
        result[puuid] = bool(is_active)
    return result
