#!/bin/sh
set -e

# Автоопределение подсети хоста (например 192.168.1.50 → 192.168.1.0/24)
if [ -z "$ALLOWED_SUBNET" ]; then
    HOST_IP=$(python -c "
import socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.connect(('8.8.8.8', 80))
print(s.getsockname()[0])
s.close()
" 2>/dev/null || echo "")
    if [ -n "$HOST_IP" ]; then
        SUBNET=$(echo "$HOST_IP" | cut -d. -f1-3).0/24
        export ALLOWED_SUBNET="$SUBNET"
        echo "[entrypoint] Подсеть: $ALLOWED_SUBNET"
    fi
fi

PG_HOST="${PG_HOST:-host.docker.internal}"
PG_PORT="${PG_PORT:-5432}"
PG_USER="${PG_USER:-postgres}"
PG_PASS="${PG_PASS:-postgres}"
PG_DB="${PG_DB:-ags}"

echo "[entrypoint] Ожидание PostgreSQL на ${PG_HOST}:${PG_PORT}..."

until PGPASSWORD="$PG_PASS" python -c "
import psycopg2, sys
try:
    psycopg2.connect(host='${PG_HOST}', port=${PG_PORT}, dbname='${PG_DB}', user='${PG_USER}', password='${PG_PASS}')
except Exception:
    sys.exit(1)
" 2>/dev/null; do
    echo "[entrypoint] PostgreSQL недоступен, жду 3 сек..."
    sleep 3
done

echo "[entrypoint] PostgreSQL готов. Запускаю микросервис..."

uvicorn main:app \
    --host 0.0.0.0 \
    --port 8000 \
    --no-access-log \
    --workers 1 &

UVICORN_PID=$!

# Прогрев: ждём пока uvicorn поднимется, делаем первый запрос
echo "[entrypoint] Ожидание uvicorn..."
until python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')" 2>/dev/null; do
    sleep 1
done
echo "[entrypoint] Прогрев приложения..."
python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/')" 2>/dev/null || true
echo "[entrypoint] Готов к работе."

wait $UVICORN_PID
